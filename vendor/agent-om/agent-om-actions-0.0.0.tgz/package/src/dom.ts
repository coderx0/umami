import type { ActionFailure } from './types'

/** Thrown inside a step; the executor turns it into an ActionError naming the step. */
export class StepFailure extends Error {
  reason: ActionFailure
  constructor(reason: ActionFailure, message: string) {
    super(message)
    this.reason = reason
  }
}

// ---------- timing ----------

export function sleep(ms: number, signal?: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    if (signal?.aborted) return reject(aborted())
    const timer = setTimeout(done, ms)
    signal?.addEventListener('abort', onAbort, { once: true })
    function done() {
      signal?.removeEventListener('abort', onAbort)
      resolve()
    }
    function onAbort() {
      clearTimeout(timer)
      reject(aborted())
    }
  })
}

export function nextFrame(signal?: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    if (signal?.aborted) return reject(aborted())
    requestAnimationFrame(() => (signal?.aborted ? reject(aborted()) : resolve()))
  })
}

export const aborted = () => new StepFailure('aborted', 'aborted')

// ---------- readiness ----------

/** Why the element can't be acted on right now, or undefined if it can. Each of these can clear by itself. */
export function blocker(el: Element | null | undefined, { enabled = true } = {}): ActionFailure | undefined {
  if (!el?.isConnected) return 'not-found'
  if (!el.checkVisibility()) return 'not-rendered'
  if (el.closest('[inert]')) return 'inert'
  if (enabled && (el.matches(':disabled') || el.closest('[aria-disabled="true"]'))) return 'disabled'
  return undefined
}

/**
 * Where a pointer would act on the element: the centre of its box, or, for an
 * inline element broken across lines (a link that wraps), the centre of its
 * largest piece: the centre of the whole box can fall between the pieces, on
 * the text around them.
 */
export function centerOf(el: Element) {
  const pieces = [...el.getClientRects()].filter((r) => r.width > 0 && r.height > 0)
  const r = pieces.length > 1 ? pieces.reduce((a, b) => (b.width * b.height > a.width * a.height ? b : a)) : el.getBoundingClientRect()
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 }
}

/**
 * The element a pointer at the target's centre would hit, if that hit reaches
 * the target: the target, something inside it, or a label for it.
 */
export function hitTarget(el: Element): Element | undefined {
  const { x, y } = centerOf(el)
  if (x < 0 || y < 0 || x >= innerWidth || y >= innerHeight) return undefined
  const hit = document.elementFromPoint(x, y)
  if (!hit) return undefined
  if (el.contains(hit)) return hit
  const label = hit.closest('label')
  if (label && label.control === el) return hit
  return undefined
}

/**
 * Whether the element's centre is on screen: inside the viewport and inside
 * every ancestor that clips its overflow. Unlike hitTarget, being covered
 * doesn't count against it.
 */
export function inView(el: Element): boolean {
  const { x, y } = centerOf(el)
  if (x < 0 || y < 0 || x >= innerWidth || y >= innerHeight) return false
  for (let a = el.parentElement; a && a !== document.body; a = a.parentElement) {
    const style = getComputedStyle(a)
    if (style.overflowX === 'visible' && style.overflowY === 'visible') continue
    const r = a.getBoundingClientRect()
    if (x < r.left || x >= r.right || y < r.top || y >= r.bottom) return false
  }
  return true
}

/** Scroll until the element stops moving (smooth scrolling takes several frames). */
export async function scrollIntoView(el: Element, smooth: boolean, block: ScrollLogicalPosition, signal?: AbortSignal) {
  el.scrollIntoView({ behavior: smooth ? 'smooth' : 'instant', block, inline: 'nearest' })
  if (!smooth) return
  let last = ''
  let stable = 0
  const deadline = performance.now() + 3000
  while (stable < 5 && performance.now() < deadline) {
    await nextFrame(signal)
    const r = el.getBoundingClientRect()
    const pos = `${r.left},${r.top}`
    stable = pos === last ? stable + 1 : 0
    last = pos
  }
}

// ---------- events ----------

const FOCUSABLE =
  'a[href], area[href], button, input, select, textarea, summary, iframe, [tabindex], [contenteditable=""], [contenteditable="true"]'

/** How long the button is held. A real press takes time, and apps react to pointerdown before the release. */
const PRESS_MS = 30

/**
 * The event sequence of a mouse click, dispatched on the element under the
 * pointer. Pointer events matter: libraries such as Radix open menus and
 * selects on pointerdown, not click, and then expect the release to come
 * later (a Radix Select swallows the release that ends its opening click).
 */
export async function pointerClick(hit: Element, x: number, y: number, signal?: AbortSignal) {
  const mouse = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0 }
  const pointer = { ...mouse, pointerId: 1, pointerType: 'mouse', isPrimary: true }

  // A cancelled pointerdown suppresses the compatibility mouse events, not the click.
  const down = hit.dispatchEvent(new PointerEvent('pointerdown', { ...pointer, buttons: 1 }))
  const mouseDown = down && hit.dispatchEvent(new MouseEvent('mousedown', { ...mouse, buttons: 1, detail: 1 }))
  if (mouseDown) {
    const focusable = hit.closest(FOCUSABLE)
    if (focusable instanceof HTMLElement && !focusable.matches(':disabled')) focusable.focus({ preventScroll: true })
  }
  await sleep(PRESS_MS, signal)
  hit.dispatchEvent(new PointerEvent('pointerup', { ...pointer, buttons: 0 }))
  if (down) hit.dispatchEvent(new MouseEvent('mouseup', { ...mouse, buttons: 0, detail: 1 }))
  hit.dispatchEvent(new MouseEvent('click', { ...mouse, buttons: 0, detail: 1 }))
}

const NOT_TEXT = new Set(['checkbox', 'radio', 'file', 'button', 'submit', 'reset', 'image', 'hidden'])

export function editable(el: Element): HTMLInputElement | HTMLTextAreaElement {
  const ok = el instanceof HTMLTextAreaElement || (el instanceof HTMLInputElement && !NOT_TEXT.has(el.type))
  if (!ok) throw new StepFailure('not-editable', `<${el.localName}> is not a text field`)
  if (el.readOnly) throw new StepFailure('readonly', 'the field is read-only')
  return el
}

/**
 * Set the value through the native setter, then fire input and change.
 * Assigning `el.value` directly is invisible to React's controlled inputs.
 */
export function setValue(el: HTMLInputElement | HTMLTextAreaElement, value: string) {
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  el.focus({ preventScroll: true })
  Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, value)
  el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertReplacementText', data: value }))
  el.dispatchEvent(new Event('change', { bubbles: true }))
}

/**
 * Select options by value, or else by label. Fires input and change only if the selection changed.
 * The select takes the focus first, as it does when a user picks from it: a popup that closes when
 * the focus leaves it (a non-modal popover) closes, instead of staying open over a page that moved.
 */
export function selectOptions(el: Element, values: string[]) {
  if (!(el instanceof HTMLSelectElement)) throw new StepFailure('not-selectable', `<${el.localName}> is not a <select>`)
  if (values.length !== 1 && !el.multiple)
    throw new StepFailure('not-selectable', 'several values for a single-choice <select>')
  const options = [...el.options]
  const wanted = values.map((v) => {
    const option = options.find((o) => o.value === v) ?? options.find((o) => o.label.trim() === v)
    if (!option) throw new StepFailure('no-option', `no option "${v}"`)
    if (option.disabled) throw new StepFailure('disabled', `option "${v}" is disabled`)
    return option
  })
  el.focus({ preventScroll: true })
  const before = options.map((o) => o.selected).join()
  for (const o of options) o.selected = wanted.includes(o)
  if (options.map((o) => o.selected).join() === before) return
  el.dispatchEvent(new Event('input', { bubbles: true, composed: true }))
  el.dispatchEvent(new Event('change', { bubbles: true }))
}

/** On/off state of a toggle-like control; undefined if it has none. "mixed" counts as off. */
export function toggleState(el: Element): boolean | undefined {
  if (el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio')) return el.checked
  for (const attr of ['aria-checked', 'aria-pressed', 'aria-expanded']) {
    const v = el.getAttribute(attr)
    if (v !== null) return v === 'true'
  }
  return undefined
}

export function formOf(el: Element): { form: HTMLFormElement; submitter?: HTMLElement } {
  if (el instanceof HTMLFormElement) return { form: el }
  const form = 'form' in el && el.form instanceof HTMLFormElement ? el.form : el.closest('form')
  if (!form) throw new StepFailure('no-form', `<${el.localName}> is not in a form`)
  const isSubmitter =
    (el instanceof HTMLButtonElement && el.type === 'submit') ||
    (el instanceof HTMLInputElement && (el.type === 'submit' || el.type === 'image'))
  return { form, submitter: isSubmitter ? (el as HTMLElement) : undefined }
}

// ---------- highlight ----------

/**
 * Outline the element for `ms`. The overlay is mounted on <html>, outside
 * <body>, so DOM observers on the body (such as the projector) never see it.
 */
export async function highlight(el: Element, ms: number, color: string, signal?: AbortSignal) {
  const r = el.getBoundingClientRect()
  const box = document.createElement('div')
  box.setAttribute('aria-hidden', 'true')
  box.dataset.actionHighlight = ''
  Object.assign(box.style, {
    position: 'fixed',
    left: `${r.left - 3}px`,
    top: `${r.top - 3}px`,
    width: `${r.width + 6}px`,
    height: `${r.height + 6}px`,
    border: `2px solid ${color}`,
    borderRadius: '4px',
    background: `color-mix(in srgb, ${color} 12%, transparent)`,
    pointerEvents: 'none',
    zIndex: '2147483647',
    boxSizing: 'border-box',
  })
  document.documentElement.append(box)
  try {
    await sleep(ms, signal)
  } finally {
    box.remove()
  }
}
