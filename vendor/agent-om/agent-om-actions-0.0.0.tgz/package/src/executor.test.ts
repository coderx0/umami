import { afterEach, describe, expect, it } from 'vitest'
import {
  ActionError,
  createActionExecutor,
  type ActionExecutorOptions,
  type ActionFailure,
  type ActionTarget,
} from './index'

const mounted: HTMLElement[] = []

function mount(html: string) {
  const root = document.createElement('div')
  root.innerHTML = html
  document.body.append(root)
  mounted.push(root)
  return root
}

afterEach(() => {
  for (const el of mounted.splice(0)) el.remove()
  window.scrollTo(0, 0)
})

const $ = <T extends Element = HTMLElement>(sel: string) => document.querySelector<T>(sel)!
const byTestId = (id: string) => document.querySelector(`[data-testid="${id}"]`)

/** Instant scrolling and a short timeout keep tests fast. */
const executor = (options: ActionExecutorOptions = {}) =>
  createActionExecutor({ smoothScroll: false, timeout: 300, resolveTarget: byTestId, ...options })

async function failure(p: PromiseLike<void>) {
  try {
    await p
  } catch (e) {
    return e as ActionError
  }
  throw new Error('expected the actions to fail')
}

function record(el: Element, types: string[]) {
  const seen: string[] = []
  for (const t of types) el.addEventListener(t, (e) => seen.push(e.type))
  return seen
}

describe('click', () => {
  it('dispatches the pointer, mouse and click sequence and focuses the target', async () => {
    mount(`<button>Save</button>`)
    const seen = record($('button'), ['pointerdown', 'mousedown', 'focus', 'pointerup', 'mouseup', 'click'])
    await executor().click($('button'))
    expect(seen).toEqual(['pointerdown', 'mousedown', 'focus', 'pointerup', 'mouseup', 'click'])
    expect(document.activeElement).toBe($('button'))
  })

  it('runs native activation: a checkbox toggles, a link navigates', async () => {
    mount(`<input type="checkbox" aria-label="Agree"><a href="#clicked">Go</a>`)
    await executor().click($('input')).click($('a'))
    expect($<HTMLInputElement>('input').checked).toBe(true)
    expect(location.hash).toBe('#clicked')
    history.replaceState(null, '', location.pathname)
  })

  it('skips mouse events and focus when pointerdown is cancelled, but still clicks', async () => {
    mount(`<button>Open</button>`)
    $('button').addEventListener('pointerdown', (e) => e.preventDefault())
    const seen = record($('button'), ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'])
    await executor().click($('button'))
    expect(seen).toEqual(['pointerdown', 'pointerup', 'click'])
    expect(document.activeElement).not.toBe($('button'))
  })

  it('clicks a visually hidden checkbox through its label', async () => {
    mount(`<label style="position:relative;display:inline-block;padding:8px">
      <input type="checkbox" style="position:absolute;inset:0;opacity:0;z-index:-1">Agree</label>`)
    await executor().click($('input'))
    expect($<HTMLInputElement>('input').checked).toBe(true)
  })

  it('clicks a link broken across two lines on its largest piece, not the middle of its box', async () => {
    // the box's centre falls on the paragraph's text, between the link's two pieces
    mount(`<p style="width: 240px; font: 16px/20px sans-serif; margin: 0">Some words before the link, then
      <a href="#wrapped" data-testid="link">a link that wraps onto the next line</a> and more.</p>`)
    const link = $('a')
    expect(link.getClientRects().length).toBeGreaterThan(1)
    let clicked = 0
    link.addEventListener('click', (e) => (e.preventDefault(), clicked++))
    await executor().click('link')
    expect(clicked).toBe(1)
  })

  it('scrolls a far-away target into view first', async () => {
    mount(`<div style="height:3000px"></div><button>Far</button>`)
    let clicked = false
    $('button').addEventListener('click', () => (clicked = true))
    await executor().click($('button'))
    expect(clicked).toBe(true)
    const r = $('button').getBoundingClientRect()
    expect(r.top).toBeGreaterThanOrEqual(0)
    expect(r.bottom).toBeLessThanOrEqual(innerHeight)
  })

  it('waits for a target that appears later', async () => {
    mount(`<div id="slot"></div>`)
    setTimeout(() => ($('#slot').innerHTML = `<button data-testid="late">Late</button>`), 100)
    let clicked = false
    document.addEventListener('click', () => (clicked = true), { once: true })
    await executor().click('late')
    expect(clicked).toBe(true)
  })

  it('waits for a disabled target to become enabled', async () => {
    mount(`<button disabled>Save</button>`)
    setTimeout(() => $<HTMLButtonElement>('button').removeAttribute('disabled'), 100)
    await executor().click($('button'))
  })

  it.each([
    ['not-found', `<p>nothing</p>`, () => 'missing'],
    ['not-rendered', `<button style="display:none">x</button>`, () => $('button')],
    ['disabled', `<button disabled>x</button>`, () => $('button')],
    ['disabled', `<div aria-disabled="true"><button>x</button></div>`, () => $('button')],
    ['inert', `<div inert><button>x</button></div>`, () => $('button')],
    [
      'covered',
      `<button>x</button><div style="position:fixed;inset:0;background:#0003"></div>`,
      () => $('button'),
    ],
  ] satisfies [ActionFailure, string, () => ActionTarget][])('fails as %s when the target stays unusable', async (reason, html, target) => {
    mount(html)
    const e = await failure(executor().click(target()))
    expect(e).toBeInstanceOf(ActionError)
    expect(e).toMatchObject({ reason, index: 0, step: { type: 'click' } })
  })

  it('fails on a string target without resolveTarget', async () => {
    const e = await failure(createActionExecutor().click('save'))
    expect(e.reason).toBe('no-resolver')
  })
})

describe('input', () => {
  it('replaces the value and fires input then change', async () => {
    mount(`<input aria-label="Name" value="old">`)
    const seen = record($('input'), ['input', 'change'])
    await executor().input($('input'), 'Ada')
    expect($<HTMLInputElement>('input').value).toBe('Ada')
    expect(seen).toEqual(['input', 'change'])
    expect(document.activeElement).toBe($('input'))
  })

  it('works on textareas and non-text inputs that take text', async () => {
    mount(`<textarea aria-label="Notes"></textarea><input type="number" aria-label="Qty">`)
    await executor().input($('textarea'), 'line 1\nline 2').input($('input'), '3')
    expect($<HTMLTextAreaElement>('textarea').value).toBe('line 1\nline 2')
    expect($<HTMLInputElement>('input').valueAsNumber).toBe(3)
  })

  it.each([
    ['not-editable', `<input type="checkbox" aria-label="x">`],
    ['not-editable', `<div contenteditable>x</div>`],
    ['readonly', `<input readonly aria-label="x">`],
  ] as const)('fails as %s', async (reason, html) => {
    mount(html)
    expect((await failure(executor().input(mounted[0].firstElementChild!, 'x'))).reason).toBe(reason)
  })
})

describe('select', () => {
  const html = `<select aria-label="Range">
    <option value="7d">Last 7 days</option><option value="30d" selected>Last 30 days</option>
    <option value="90d" disabled>Last 90 days</option></select>`

  it('selects by value or by label, firing change', async () => {
    mount(html)
    const seen = record($('select'), ['change'])
    await executor().select($('select'), '7d')
    expect($<HTMLSelectElement>('select').value).toBe('7d')
    await executor().select($('select'), 'Last 30 days')
    expect($<HTMLSelectElement>('select').value).toBe('30d')
    expect(seen).toEqual(['change', 'change'])
  })

  it('fires nothing when the option is already selected', async () => {
    mount(html)
    const seen = record($('select'), ['change'])
    await executor().select($('select'), '30d')
    expect(seen).toEqual([])
  })

  it('focuses the select first, as a user picking from it does: a popup that closes when the focus leaves it closes', async () => {
    mount(`<button aria-expanded="true">Filter</button><div role="dialog" aria-label="Filter"><input type="checkbox" aria-label="Reddit"></div>${html}`)
    const popup = $('[role="dialog"]')
    $<HTMLInputElement>('input').focus()
    popup.addEventListener('focusout', (e) => {
      if (!popup.contains(e.relatedTarget as Node | null)) popup.remove()
    })
    await executor().select($('select'), '7d')
    expect(document.activeElement).toBe($('select'))
    expect(popup.isConnected).toBe(false)
  })

  it('selects several options in a multiple select', async () => {
    mount(`<select multiple aria-label="Days"><option>Mon</option><option>Tue</option><option>Wed</option></select>`)
    await executor().select($('select'), ['Mon', 'Wed'])
    expect([...$<HTMLSelectElement>('select').selectedOptions].map((o) => o.value)).toEqual(['Mon', 'Wed'])
  })

  it.each([
    ['no-option', html, 'yesterday'],
    ['disabled', html, '90d'],
    ['not-selectable', html, ['7d', '30d']],
    ['not-selectable', `<input aria-label="x">`, 'x'],
  ] as const)('fails as %s', async (reason, markup, value) => {
    mount(markup)
    expect((await failure(executor().select(mounted[0].firstElementChild!, value as string))).reason).toBe(reason)
  })
})

describe('toggle', () => {
  function pressButton() {
    mount(`<button aria-pressed="false">Bold</button>`)
    const b = $('button')
    b.addEventListener('click', () => b.setAttribute('aria-pressed', String(b.getAttribute('aria-pressed') !== 'true')))
    return b
  }

  it('flips a checkbox or a pressed button', async () => {
    mount(`<input type="checkbox" aria-label="Agree">`)
    const b = pressButton()
    await executor().toggle($('input')).toggle(b)
    expect($<HTMLInputElement>('input').checked).toBe(true)
    expect(b.getAttribute('aria-pressed')).toBe('true')
  })

  it('sets a desired state, doing nothing when it already holds', async () => {
    const b = pressButton()
    const seen = record(b, ['click'])
    await executor().toggle(b, false)
    expect(seen).toEqual([])
    await executor().toggle(b, true).toggle(b, true)
    expect(seen).toEqual(['click'])
    expect(b.getAttribute('aria-pressed')).toBe('true')
  })

  it('fails as unchanged when the click has no effect', async () => {
    mount(`<button aria-expanded="false">Menu</button>`)
    expect((await failure(executor().toggle($('button'), true))).reason).toBe('unchanged')
  })

  it('fails as not-toggleable on a plain button', async () => {
    mount(`<button>Save</button>`)
    expect((await failure(executor().toggle($('button')))).reason).toBe('not-toggleable')
  })
})

describe('submit', () => {
  it('submits the form a field belongs to, with a submit button as submitter', async () => {
    mount(`<form><input name="q" aria-label="q"><button name="go" value="1">Go</button></form>`)
    const submitters: (HTMLElement | null)[] = []
    $('form').addEventListener('submit', (e) => {
      e.preventDefault()
      submitters.push(e.submitter)
    })
    await executor().submit($('input')).submit($('button'))
    expect(submitters).toEqual([null, $('button')])
  })

  it('fails as invalid when constraint validation fails, without submitting', async () => {
    mount(`<form><input required aria-label="Email"></form>`)
    let submitted = false
    $('form').addEventListener('submit', (e) => {
      e.preventDefault()
      submitted = true
    })
    expect((await failure(executor().submit($('form')))).reason).toBe('invalid')
    expect(submitted).toBe(false)
  })

  it('fails as no-form outside a form', async () => {
    mount(`<button>Go</button>`)
    expect((await failure(executor().submit($('button')))).reason).toBe('no-form')
  })
})

describe('scroll', () => {
  it('centres the target, also with smooth scrolling', async () => {
    mount(`<div style="height:3000px"></div><section style="height:100px">Pricing</section><div style="height:3000px"></div>`)
    await executor({ smoothScroll: true }).scroll($('section'))
    const r = $('section').getBoundingClientRect()
    expect(Math.abs(r.top + r.height / 2 - innerHeight / 2)).toBeLessThan(2)
  })

  it('scrolls disabled targets (only acting needs them enabled)', async () => {
    mount(`<div style="height:3000px"></div><button disabled>Far</button>`)
    await executor().scroll($('button'))
    expect($('button').getBoundingClientRect().top).toBeLessThan(innerHeight)
  })
})

describe('scrolling into view before acting', () => {
  const far = `<div style="height:3000px"></div>`
  const centred = (el: Element) => {
    const r = el.getBoundingClientRect()
    return Math.abs(r.top + r.height / 2 - innerHeight / 2) < 2
  }

  it.each([
    ['input', `<input aria-label="Name">`, (x: ReturnType<typeof executor>) => x.input($('input'), 'Ada')],
    ['select', `<select aria-label="Range"><option>7d</option><option>30d</option></select>`, (x: ReturnType<typeof executor>) => x.select($('select'), '30d')],
    ['submit', `<form><input aria-label="q"></form>`, (x: ReturnType<typeof executor>) => x.submit($('input'))],
  ])('%s scrolls a far-away target to the centre', async (_, html, act) => {
    mount(`${far}${html}${far}`)
    $('form')?.addEventListener('submit', (e) => e.preventDefault())
    await act(executor())
    expect(centred($('input, select'))).toBe(true)
  })

  it('leaves the page alone when the target is already on screen', async () => {
    mount(`<div style="height:300px"></div><input aria-label="Name">${far}`)
    window.scrollTo(0, 100)
    await executor().input($('input'), 'Ada')
    expect(scrollY).toBe(100)
  })

  it('scrolls a target clipped inside a scroll container', async () => {
    // On screen by the viewport, but clipped by the container.
    mount(`<div style="height:200px;overflow:auto"><div style="height:400px"></div><input aria-label="Name"></div>`)
    await executor().input($('input'), 'Ada')
    const box = $('div').getBoundingClientRect()
    const r = $('input').getBoundingClientRect()
    expect(r.top).toBeGreaterThanOrEqual(box.top)
    expect(r.bottom).toBeLessThanOrEqual(box.bottom)
  })

  it('acts on a covered target without failing (no pointer needed)', async () => {
    mount(`<input aria-label="Name"><div style="position:fixed;inset:0;background:#0003"></div>`)
    await executor().input($('input'), 'Ada')
    expect($<HTMLInputElement>('input').value).toBe('Ada')
  })
})

describe('wait', () => {
  it('waits a duration', async () => {
    const t = performance.now()
    await executor().wait(120)
    expect(performance.now() - t).toBeGreaterThanOrEqual(115)
  })

  it('waits for a condition or a target', async () => {
    mount(`<div id="slot"></div>`)
    let ready = false
    setTimeout(() => (ready = true), 50)
    setTimeout(() => ($('#slot').innerHTML = `<p data-testid="done">Done</p>`), 100)
    await executor().wait(() => ready).wait('done')
  })

  it('fails as timeout when the condition is never met', async () => {
    const e = await failure(executor().wait(() => false, 50))
    expect(e).toMatchObject({ reason: 'timeout', step: { type: 'wait', timeout: 50 } })
  })
})

describe('sequences', () => {
  it('runs a chain in order, and starts without being awaited', async () => {
    mount(`<input aria-label="Name"><button>Save</button>`)
    const steps: string[] = []
    let saved = ''
    $('button').addEventListener('click', () => (saved = $<HTMLInputElement>('input').value))
    executor({ onStep: (s, i) => steps.push(`${i}:${s.type}`) })
      .input($('input'), 'Ada')
      .wait(20)
      .click($('button'))
    await expect.poll(() => saved).toBe('Ada')
    expect(steps).toEqual(['0:input', '1:wait', '2:click'])
  })

  it('runs the same steps given as data', async () => {
    mount(`<input data-testid="name" aria-label="Name"><button data-testid="save">Save</button>`)
    let saved = ''
    $('button').addEventListener('click', () => (saved = $<HTMLInputElement>('input').value))
    await executor().run([
      { type: 'input', target: 'name', value: 'Ada' },
      { type: 'click', target: 'save' },
    ])
    expect(saved).toBe('Ada')
  })

  it('stops at the first failure and reports which step failed', async () => {
    mount(`<button>Save</button>`)
    let clicks = 0
    $('button').addEventListener('click', () => clicks++)
    const e = await failure(executor().click($('button')).click('missing').click($('button')))
    expect(e).toMatchObject({ reason: 'not-found', index: 1 })
    expect(e.message).toContain('step 2 (click)')
    expect(clicks).toBe(1)
  })

  it('refuses new steps once the chain is running', async () => {
    const chain = executor().wait(10)
    await Promise.resolve()
    expect(() => chain.wait(10)).toThrow(/already running/)
    await chain
  })

  it('can be aborted mid-sequence', async () => {
    mount(`<button>Save</button>`)
    let clicked = false
    $('button').addEventListener('click', () => (clicked = true))
    const controller = new AbortController()
    const running = executor().run([{ type: 'wait', ms: 1000 }, { type: 'click', target: $('button') }], {
      signal: controller.signal,
    })
    setTimeout(() => controller.abort(), 20)
    expect((await failure(running)).reason).toBe('aborted')
    expect(clicked).toBe(false)
  })
})

describe('highlight', () => {
  it('outlines the target outside <body> for the given time, then removes it', async () => {
    mount(`<button>Save</button>`)
    const bodyChanges: MutationRecord[] = []
    const observer = new MutationObserver((r) => bodyChanges.push(...r))
    observer.observe(document.body, { subtree: true, childList: true, attributes: true })
    let during: Element | null = null
    $('button').addEventListener('click', () => (during = document.querySelector('[data-action-highlight]')))

    const running = executor({ highlight: 150 }).click($('button'))
    await expect.poll(() => document.querySelector('[data-action-highlight]')).not.toBeNull()
    const box = document.querySelector('[data-action-highlight]')!
    expect(box.parentElement).toBe(document.documentElement)
    const b = $('button').getBoundingClientRect()
    const h = box.getBoundingClientRect()
    expect(h.left).toBeLessThan(b.left)
    expect(h.right).toBeGreaterThan(b.right)
    await running

    observer.disconnect()
    expect(during).toBeNull() // gone before the click
    expect(document.querySelector('[data-action-highlight]')).toBeNull()
    expect(bodyChanges.filter((r) => r.type === 'childList')).toEqual([])
  })
})
