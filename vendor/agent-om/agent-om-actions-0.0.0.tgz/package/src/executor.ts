import {
  StepFailure,
  blocker,
  centerOf,
  editable,
  formOf,
  highlight,
  hitTarget,
  inView,
  pointerClick,
  scrollIntoView,
  selectOptions,
  setValue,
  sleep,
  toggleState,
} from './dom'
import type { ActionFailure, ActionStep, ActionTarget, WaitCondition } from './types'

export type ActionExecutorOptions = {
  /** Turns a string target into an element (e.g. an id lookup). Without it, string targets fail. */
  resolveTarget?: (target: string) => Element | null | undefined
  /**
   * ms a step waits for its target to become actionable (found, rendered,
   * enabled, not covered), and the default for `wait(condition)`. Default 5000.
   */
  timeout?: number
  /** Smooth scrolling. Default: on, unless the user prefers reduced motion. */
  smoothScroll?: boolean
  /** ms to outline the target before click, input, select, toggle and submit. Default 0 (off). */
  highlight?: number
  /** Highlight colour (any CSS colour). Default #2563eb. */
  highlightColor?: string
  /** Called before each step runs. */
  onStep?: (step: ActionStep, index: number) => void
}

export type RunOptions = { signal?: AbortSignal }

/** A step failed. Steps after it didn't run. */
export class ActionError extends Error {
  reason: ActionFailure
  step: ActionStep
  /** position of the failed step in the sequence */
  index: number
  constructor(reason: ActionFailure, step: ActionStep, index: number, detail: string) {
    super(`step ${index + 1} (${step.type}) failed: ${detail}`)
    this.name = 'ActionError'
    this.reason = reason
    this.step = step
    this.index = index
  }
}

/**
 * A sequence being built. It starts running on its own once the expression
 * that builds it finishes (a microtask later); await it for the result.
 */
export type ActionChain = PromiseLike<void> & {
  click(target: ActionTarget): ActionChain
  input(target: ActionTarget, value: string): ActionChain
  select(target: ActionTarget, value: string | string[]): ActionChain
  toggle(target: ActionTarget, on?: boolean): ActionChain
  submit(target: ActionTarget): ActionChain
  scroll(target: ActionTarget, options?: { smooth?: boolean }): ActionChain
  wait(ms: number): ActionChain
  wait(until: WaitCondition, timeout?: number): ActionChain
  catch<T = never>(onRejected: (reason: unknown) => T | PromiseLike<T>): Promise<void | T>
  finally(onFinally: () => void): Promise<void>
}

type ChainStart = Omit<ActionChain, 'then' | 'catch' | 'finally'>

export type ActionExecutor = ChainStart & {
  /** Run steps given as data, in order. Rejects with an ActionError at the first failure. */
  run(steps: readonly ActionStep[], options?: RunOptions): Promise<void>
}

const POLL_MS = 20

export function createActionExecutor(options: ActionExecutorOptions = {}): ActionExecutor {
  const timeout = options.timeout ?? 5000
  const highlightMs = options.highlight ?? 0
  const highlightColor = options.highlightColor ?? '#2563eb'
  const smoothDefault = () => options.smoothScroll ?? !matchMedia('(prefers-reduced-motion: reduce)').matches

  function resolve(target: ActionTarget): Element | null {
    if (typeof target === 'string') {
      if (!options.resolveTarget) throw new StepFailure('no-resolver', `"${target}" needs the resolveTarget option`)
      return options.resolveTarget(target) ?? null
    }
    if (typeof target === 'function') return target() ?? null
    return target
  }

  /**
   * Wait until the target can be acted on, scrolling it into view first:
   * - `pointer`: until a pointer at its centre reaches it, else it's `covered`
   * - `view`: if its centre is off screen (covering doesn't matter)
   * - `none`: no scrolling
   */
  async function ready(
    target: ActionTarget,
    signal: AbortSignal | undefined,
    reach: 'pointer' | 'view' | 'none',
    enabled = true,
  ) {
    const deadline = performance.now() + timeout
    for (;;) {
      const el = resolve(target)
      let reason = blocker(el, { enabled })
      if (!reason && reach === 'pointer' && !hitTarget(el!)) {
        await scrollIntoView(el!, smoothDefault(), 'center', signal)
        if (!hitTarget(el!)) reason = 'covered'
      } else if (!reason && reach === 'view' && !inView(el!)) {
        await scrollIntoView(el!, smoothDefault(), 'center', signal)
      }
      if (!reason) return el!
      if (performance.now() >= deadline) throw new StepFailure(reason, `target ${reason} after ${timeout}ms`)
      await sleep(POLL_MS, signal)
    }
  }

  async function mark(el: Element, signal?: AbortSignal) {
    if (highlightMs > 0) await highlight(el, highlightMs, highlightColor, signal)
  }

  async function click(target: ActionTarget, signal?: AbortSignal) {
    const el = await ready(target, signal, 'pointer')
    await mark(el, signal)
    // Re-check after the highlight: the page may have moved under it.
    const hit = hitTarget(el)
    if (!hit) throw new StepFailure('covered', 'target covered')
    const { x, y } = centerOf(el)
    await pointerClick(hit, x, y, signal)
  }

  async function waitUntil(until: WaitCondition, ms: number, signal?: AbortSignal) {
    const met = () => (typeof until === 'string' ? resolve(until) : until())
    const deadline = performance.now() + ms
    while (!met()) {
      if (performance.now() >= deadline) throw new StepFailure('timeout', `condition not met after ${ms}ms`)
      await sleep(POLL_MS, signal)
    }
  }

  async function runStep(step: ActionStep, signal?: AbortSignal) {
    switch (step.type) {
      case 'click':
        return click(step.target, signal)
      case 'input': {
        const field = editable(await ready(step.target, signal, 'view'))
        await mark(field, signal)
        return setValue(field, step.value)
      }
      case 'select': {
        const el = await ready(step.target, signal, 'view')
        await mark(el, signal)
        return selectOptions(el, Array.isArray(step.value) ? step.value : [step.value])
      }
      case 'toggle': {
        const current = toggleState(await ready(step.target, signal, 'none'))
        if (current === undefined) throw new StepFailure('not-toggleable', 'target has no checked, pressed or expanded state')
        const want = step.on ?? !current
        if (current === want) return
        await click(step.target, signal)
        const done = () => {
          const el = resolve(step.target)
          return el && toggleState(el) === want
        }
        try {
          await waitUntil(done, timeout, signal)
        } catch (e) {
          if (e instanceof StepFailure && e.reason === 'timeout')
            throw new StepFailure('unchanged', `clicked, but it didn't turn ${want ? 'on' : 'off'}`)
          throw e
        }
        return
      }
      case 'submit': {
        const el = await ready(step.target, signal, 'view')
        const { form, submitter } = formOf(el)
        await mark(el, signal)
        const novalidate = form.noValidate || (submitter as HTMLButtonElement | undefined)?.formNoValidate
        if (!novalidate && !form.checkValidity()) throw new StepFailure('invalid', 'the form has invalid fields')
        return form.requestSubmit(submitter)
      }
      case 'scroll': {
        const el = await ready(step.target, signal, 'none', false)
        return scrollIntoView(el, step.smooth ?? smoothDefault(), 'center', signal)
      }
      case 'wait':
        if ('ms' in step) return sleep(step.ms, signal)
        return waitUntil(step.until, step.timeout ?? timeout, signal)
      default:
        throw new Error(`unknown step type "${(step as { type: unknown }).type}"`)
    }
  }

  async function run(steps: readonly ActionStep[], { signal }: RunOptions = {}) {
    for (const [index, step] of steps.entries()) {
      try {
        if (signal?.aborted) throw new StepFailure('aborted', 'aborted')
        options.onStep?.(step, index)
        await runStep(step, signal)
      } catch (e) {
        if (e instanceof StepFailure) throw new ActionError(e.reason, step, index, e.message)
        throw e
      }
    }
  }

  function chain(): ActionChain {
    const steps: ActionStep[] = []
    let running: Promise<void> | undefined
    const start = () => (running ??= run(steps))
    queueMicrotask(start)
    const add = (step: ActionStep) => {
      if (running) throw new Error('this sequence is already running; start a new one from the executor')
      steps.push(step)
      return api
    }
    const api: ActionChain = {
      click: (target) => add({ type: 'click', target }),
      input: (target, value) => add({ type: 'input', target, value }),
      select: (target, value) => add({ type: 'select', target, value }),
      toggle: (target, on) => add(on === undefined ? { type: 'toggle', target } : { type: 'toggle', target, on }),
      submit: (target) => add({ type: 'submit', target }),
      scroll: (target, opts) => add({ type: 'scroll', target, ...opts }),
      wait: (arg: number | WaitCondition, ms?: number) =>
        add(typeof arg === 'number' ? { type: 'wait', ms: arg } : { type: 'wait', until: arg, timeout: ms }),
      then: (onFulfilled, onRejected) => start().then(onFulfilled, onRejected),
      catch: (onRejected) => start().catch(onRejected),
      finally: (onFinally) => start().finally(onFinally),
    }
    return api
  }

  return {
    run,
    click: (t) => chain().click(t),
    input: (t, v) => chain().input(t, v),
    select: (t, v) => chain().select(t, v),
    toggle: (t, on) => chain().toggle(t, on),
    submit: (t) => chain().submit(t),
    scroll: (t, o) => chain().scroll(t, o),
    wait: ((arg: number | WaitCondition, ms?: number) =>
      typeof arg === 'number' ? chain().wait(arg) : chain().wait(arg, ms)) as ActionChain['wait'],
  }
}
