/**
 * A small, fixed set of DOM actions run as a sequence. Callers describe what to
 * do; they never run arbitrary script. Framework-agnostic: plain DOM only, and
 * independent of the projection.
 */
export { createActionExecutor, ActionError } from './executor'
export type { ActionChain, ActionExecutor, ActionExecutorOptions, RunOptions } from './executor'
export { ACTION_FAILURES } from './types'
export type { ActionFailure, ActionStep, ActionTarget, WaitCondition } from './types'
