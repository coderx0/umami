import { playwright } from '@vitest/browser-playwright'
import { defineConfig } from 'vitest/config'

// Actions depend on real layout (hit testing, scrolling) and real event
// dispatch, which jsdom doesn't implement, so tests run in a real browser.
export default defineConfig({
  test: {
    include: ['src/**/*.test.ts'],
    browser: {
      enabled: true,
      headless: true,
      // Playwright's own Chromium (full browser, new headless mode), pinned by the
      // Playwright version: `pnpm exec playwright install chromium`
      provider: playwright({ launchOptions: { channel: 'chromium' } }),
      instances: [{ browser: 'chromium' }],
      viewport: { width: 1280, height: 900 },
    },
  },
})
