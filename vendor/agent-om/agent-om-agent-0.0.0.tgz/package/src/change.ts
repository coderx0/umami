import type { SemanticNode, SemanticState } from '@agent-om/core'
import { indexNodes, nameOf, valueOf } from './describe'

// What an action changed, for the history the decision model reads.

export const NO_CHANGE = 'no visible change'

/**
 * What an action changed, in a few words, for the history: a new page, a popup
 * opened or closed, controls whose value, label or state changed (by name),
 * and what appeared and went (by name when it's up to 3, else how many). Values are compared
 * with each node as last `seen`: while a popup is open the rest of the page is
 * hidden, so `before` may not contain the control the popup changed. When a
 * popup closes, the page is back, all of it "new" to `before`: what the run
 * has never seen is what the popup's step brought (a confirmation, the new
 * key it created), and it's said.
 */
export function changeSummary(
  before: SemanticState,
  after: SemanticState,
  seen: ReadonlyMap<string, SemanticNode> = new Map(),
  /** nodes whose changes, appearing and going go unsaid (the fields a fill set and their errors: its own line says them) */
  ignore: ReadonlySet<string> = new Set(),
) {
  if (before.context.path !== after.context.path) return `now on ${after.context.path}`
  const a = indexNodes(before.root)
  const b = indexNodes(after.root)
  const parts: string[] = []
  const opened = after.context.modalId !== before.context.modalId
  // A popup opening or closing hides or reveals the whole page: name the popup, not the page.
  if (before.context.modalId && opened) parts.push(`closed ${nameOf(a.get(before.context.modalId)!.node)}`)
  if (after.context.modalId && opened) parts.push(`opened ${nameOf(b.get(after.context.modalId)!.node)}`)
  const topmost = (from: typeof a, other: typeof a) =>
    [...from.values()].filter((l) => !other.has(l.node.id) && other.has(l.parents.at(-1)?.id ?? '') && !ignore.has(l.node.id))
  // what appeared and went: named when it's a few (a checkbox that went with the choice it held),
  // counted when it's a page's worth (the outline and the options show what's there now)
  const told = (locs: ReturnType<typeof topmost>, verb: string) =>
    !locs.length ? '' : locs.length <= 3 ? `${verb}: ${locs.map((l) => appearedAs(l.node)).join(', ')}` : `${locs.length} elements ${verb}`
  if (!opened) {
    const said = [told(topmost(b, a), 'appeared'), told(topmost(a, b), 'went')].filter(Boolean)
    if (said.length) parts.push(said.join('; '))
  } else if (before.context.modalId && !after.context.modalId) {
    // back on the page: what's on it that the run has never seen, the topmost of it
    const fresh = [...b.values()].filter((l) => !a.has(l.node.id) && !seen.has(l.node.id) && !ignore.has(l.node.id))
    const ids = new Set(fresh.map((l) => l.node.id))
    const top = fresh.filter((l) => !l.parents.some((p) => ids.has(p.id)))
    if (top.length) parts.push(top.length <= 3 ? `appeared: ${top.map((l) => appearedAs(l.node)).join(', ')}` : `${top.length} elements appeared`)
  }
  const changed: string[] = []
  for (const [id, { node }] of b) {
    const old = a.get(id)?.node ?? seen.get(id)
    if (!old || ignore.has(id)) continue
    // a secret's value is never projected: that it now holds one (or none) is the change
    if (!!node.redacted !== !!old.redacted) {
      changed.push(`${nameOf(node)} ${node.redacted ? 'now holds a secret' : 'is now empty'}`)
      continue
    }
    // A label that changes with state (guidelines 1.4) is the only sign of the change.
    if (old.name && node.name && old.name !== node.name) changed.push(`${nameOf(old)} is now '${node.name}'`)
    const v = valueOf(node)
    if (v !== valueOf(old)) changed.push(`${nameOf(node)} is now '${v ?? ''}'`)
    else if (describeState(node.state) !== describeState(old.state))
      changed.push(`${nameOf(node)} is now ${describeState(node.state)}`)
  }
  if (changed.length) parts.push(changed.slice(0, 3).join(', '))
  return parts.join('; ') || NO_CHANGE
}

function describeState(state: Record<string, unknown> = {}) {
  const { focused: _f, ...rest } = state
  return Object.entries(rest)
    .map(([k, v]) => (v === true ? k : `${k} ${String(v)}`))
    .join(', ') || 'reset'
}

/** What appeared or went, by name; a message by what it says ("status 'Created the key BI dashboard.'"): a bare "alert" says nothing. */
function appearedAs(node: SemanticNode) {
  return (node.role === 'status' || node.role === 'alert') && node.text && !node.name ? `${node.role} '${node.text}'` : nameOf(node)
}
