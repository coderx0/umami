import type { Chat, ChatRequest } from './chat'
import { fieldsForWriter, fillSchema, type FieldValue, type FormField } from './form'

// The writer: a small, cheap generative model (Mercury 2.5 by default) for the
// two things the decision model can't do, write text. It never decides a step:
// which field to type into, and when the goal is met, stay with the decision
// model. Both calls get the situation as JSON, the same state every decision
// gets, and reply with structured output. It never writes a secret: a secret
// field is filled with what the user enters (secret.ts), and is no field it's
// asked for.

/**
 * The situation: the decision state (`goal`, `page`, `reading`, `memory`,
 * `history`…), plus `field` when filling one.
 */
export type WriterRequest = { state: unknown }

/** A whole form to fill: the decision state, and the form's name and fields (form.ts). */
export type FormRequest = { state: unknown; form: { name: string; fields: FormField[] } }

export type Writer = {
  /** The text to type into `field`, or null when nothing the goal or the page gives supports a value. */
  field(request: WriterRequest, signal?: AbortSignal): Promise<string | null>
  /** The final answer to the goal, from what the page showed and what was done. */
  answer(request: WriterRequest, signal?: AbortSignal): Promise<string>
  /** Every field's value, by its key (null leaves it as it is). Without it, forms are filled field by field. */
  form?(request: FormRequest, signal?: AbortSignal): Promise<Record<string, FieldValue>>
}

export const FIELD_INSTRUCTIONS =
  'You write the text an agent types into one field of a web page. The JSON message is the situation: `goal` is what the user asked for; ' +
  '`field` is the field to fill (its label and what the app says it does, such as what it searches and how it matches); `page` is what the page ' +
  'shows now; `reading` and `memory`, if present, hold content read on this page and on earlier ones; `history` is what was already done. ' +
  'Reply with `text`: exactly what to type, no quotes or explanation, so that the field does what the goal needs, following what `field` says ' +
  'about it. Use only values the goal or the page gives you; never invent personal details. If nothing given supports a value, reply with ' +
  '`text` null. An empty string clears the field.'

export const FORM_INSTRUCTIONS =
  'You fill in a form an agent is working on in a web page. The JSON message is the situation: `goal` is what the user asked for; `form` is ' +
  'the form, with its `fields`: each field\'s `key`, its `label`, what it `takes`, whether it is `required`, what it holds now (`current`), its ' +
  '`choices`, what the app says about it (`description`) and its `error`, if it shows one; `page` is what the page shows now; `reading` and ' +
  '`memory`, if present, hold content read on this page and on earlier ones; `history` is what was already done. Reply with every key: the ' +
  'value to put in that field, or null to leave it as it is. Use only values the goal or the page gives you; never invent personal details. ' +
  'A field the goal says nothing about stays null. For a choice, use one of its `choices` exactly as written. Write a value in the shape the ' +
  'field `takes` (a date as its format says). Fix a field that shows an error when the goal or the page gives the right value.'

export const ANSWER_INSTRUCTIONS =
  'You write the final answer of an agent that carried out a user\'s goal on a web page. The JSON message is the situation: `goal` is what the ' +
  'user asked for; `page` is what the page shows now; `reading` and `memory`, if present, hold content read on this page and on earlier ones; ' +
  '`history` is what was done and what came of it. Reply with `answer`: a short, direct answer to the goal in plain text, stating only what ' +
  'these show (values as the page writes them). If the goal asked for a change, say whether it was made. If they don\'t show the answer, say so.'

/**
 * The writer's two calls on a chat model with structured output. `reasoning`:
 * how much the model reasons first, `none` by default: the writer only puts what
 * it's given into words, and a model that reasons by default (Mercury 2.5, at
 * medium) spent about 1,000 hidden tokens and 3.4 s on a 25-token reply.
 */
export function chatWriter(chat: Chat, { reasoning = 'none' }: { reasoning?: ChatRequest['reasoning'] } = {}): Writer {
  return {
    async field(request, signal) {
      const reply = await chat<{ text?: unknown }>(
        {
          system: FIELD_INSTRUCTIONS,
          reasoning,
          user: request.state,
          schema: { type: 'object', properties: { text: { type: ['string', 'null'] } }, required: ['text'], additionalProperties: false },
        },
        signal,
      )
      if (reply.text === null) return null
      if (typeof reply.text !== 'string') throw new Error(`Chat API: no text in ${JSON.stringify(reply).slice(0, 200)}`)
      return reply.text.trim()
    },
    async answer(request, signal) {
      const reply = await chat<{ answer?: unknown }>(
        {
          system: ANSWER_INSTRUCTIONS,
          reasoning,
          user: request.state,
          schema: { type: 'object', properties: { answer: { type: 'string' } }, required: ['answer'], additionalProperties: false },
        },
        signal,
      )
      if (typeof reply.answer !== 'string') throw new Error(`Chat API: no answer in ${JSON.stringify(reply).slice(0, 200)}`)
      return reply.answer.trim()
    },
    async form(request, signal) {
      const { fields } = request.form
      const reply = await chat<Record<string, unknown>>(
        {
          system: FORM_INSTRUCTIONS,
          reasoning,
          user: { ...(request.state as object), form: { name: request.form.name, fields: fieldsForWriter(fields) } },
          schema: fillSchema(fields),
        },
        signal,
      )
      if (!reply || typeof reply !== 'object') throw new Error('Chat API: no values for the form')
      // a key it left out is a field it leaves alone; text is trimmed, as a field's is
      return Object.fromEntries(fields.map((f) => {
        const v = reply[f.key]
        return [f.key, typeof v === 'string' ? v.trim() : v === undefined ? null : (v as FieldValue)]
      }))
    },
  }
}
