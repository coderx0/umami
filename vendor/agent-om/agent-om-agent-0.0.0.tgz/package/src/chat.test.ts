import { describe, expect, it } from 'vitest'
import { CHAT_ATTEMPTS, openRouterChat, replyObject } from './chat'

// The chat client over a scripted fetch: what it makes of the replies models send.

const reply = (content: string) => new Response(JSON.stringify({ choices: [{ message: { content } }] }), { headers: { 'content-type': 'application/json' } })
const request = { system: 's', user: {}, schema: { type: 'object' } }

describe('the chat client', () => {
  it('reads the JSON object out of a reply that has more than the object (a stray or wrapping code fence)', () => {
    expect(replyObject('{"answer": "Mobile, Desktop, and Tablet"}\n```')).toEqual({ answer: 'Mobile, Desktop, and Tablet' })
    expect(replyObject('```json\n{"text": "sale"}\n```')).toEqual({ text: 'sale' })
    expect(replyObject('{"text": null}')).toEqual({ text: null })
    expect(replyObject('')).toBeUndefined()
    expect(replyObject('no object here')).toBeUndefined()
  })

  it('asks once more when a reply holds no JSON object (an empty reply), then gives up with what it got', async () => {
    const sent: string[] = []
    const replies = ['', '{"answer": "ok"}']
    const chat = openRouterChat('k', 'm', async (_url, init) => (sent.push(String(init?.body)), reply(replies.shift()!)))
    expect(await chat(request)).toEqual({ answer: 'ok' })
    expect(sent).toHaveLength(2)

    let calls = 0
    const empty = openRouterChat('k', 'm', async () => (calls++, reply('')))
    await expect(empty(request)).rejects.toThrow('Chat API: not JSON: ""')
    expect(calls).toBe(CHAT_ATTEMPTS)
  })

  it('sends the reasoning setting it is given', async () => {
    let body: { reasoning?: unknown } = {}
    const chat = openRouterChat('k', 'm', async (_url, init) => ((body = JSON.parse(String(init?.body))), reply('{"answer": "ok"}')))
    await chat({ ...request, reasoning: 'none' })
    expect(body.reasoning).toEqual({ effort: 'none' })
  })
})
