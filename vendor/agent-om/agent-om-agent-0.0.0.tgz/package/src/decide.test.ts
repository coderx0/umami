import { describe, expect, it } from 'vitest'
import { openRouterDecide } from './decide'

// The decision client over a scripted fetch.

describe('the decision client', () => {
  it('sends its request through the fetch it is given, and returns the answers', async () => {
    const sent: { url: string; body: unknown }[] = []
    const decide = openRouterDecide('k', 'typesafe/jev-1.13', async (url, init) => {
      sent.push({ url: String(url), body: JSON.parse(String(init?.body)) })
      return new Response(JSON.stringify({ answers: { done: { type: 'noul', noul: 0.9 } } }), { headers: { 'content-type': 'application/json' } })
    })
    const questions = { done: { type: 'noul' as const, instructions: 'i', criteria: { true: 'yes', false: 'no' } } }
    expect(await decide({ state: { goal: 'g' }, questions })).toEqual({ done: { type: 'noul', noul: 0.9 } })
    expect(sent).toEqual([{ url: 'https://openrouter.ai/api/alpha/decisions', body: { model: 'typesafe/jev-1.13', state: { goal: 'g' }, questions } }])
  })
})
