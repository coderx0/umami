import type { SemanticNode, SemanticState } from '@agent-om/core'
import { indexNodes } from './describe'

// Secrets: a secret field (a password) is filled only with what the user
// enters when the agent asks (the host's `askSecret`), never with text a model
// wrote. The value goes from the host to the executor: no model sees it, and
// no history, event or recording says it. A model only chooses to fill the
// field and hears whether it now holds a value. Both loops use this rule (our
// agent's loop.ts, Claude's view.ts); without `askSecret` a secret field
// isn't offered at all.

/**
 * Asks the user for the secret a field takes (`field`, in a few words:
 * "textbox 'Password'"). Resolves what they entered, or null when they decline.
 */
export type AskSecret = (field: string, signal?: AbortSignal) => Promise<string | null>

/**
 * A secret field, as the projection shows one: a password field, or a field it
 * redacts (any secret field once it holds a value). An empty secret field the
 * projection can't tell apart (an empty one-time-code field) is an ordinary field.
 */
export const isSecretField = (node: SemanticNode | undefined): boolean => !!node && (!!node.redacted || node.inputType === 'password')

/** Whether a secret field now holds a value (the projection says so without saying what). */
export const holdsSecret = (state: SemanticState, nodeId: string): boolean => !!indexNodes(state.root).get(nodeId)?.node.redacted
