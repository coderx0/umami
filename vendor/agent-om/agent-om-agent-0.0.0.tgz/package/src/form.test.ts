import { describe, expect, it } from 'vitest'
import type { SemanticNode, SemanticState } from '@agent-om/core'
import { fieldsForWriter, fillReadback, fillSchema, fillSteps, formFields } from './form'

// A whole form from a projection snapshot: its fields, what the writer is
// asked for, the steps its values become, and the form read back after.

const state = (children: SemanticNode[]): SemanticState => ({
  revision: 1,
  timestamp: 0,
  context: { url: 'https://app.test/invite', path: '/invite', query: {}, title: 'Invite' },
  root: { id: 'root', role: 'document', children: [{ id: 'f', role: 'form', name: 'Invite contact', children }] },
})

type Values = { first?: string; email?: string; access?: string; reports?: string[]; digest?: boolean; password?: boolean; start?: string }

/** The invite form holding `v`; the email is marked invalid when `invalid`. */
function invite(v: Values = {}, invalid = false): SemanticState {
  const radio = (name: string): SemanticNode => ({ id: `access.${name}`, role: 'radio', name, form: 'f', state: { checked: v.access === name } })
  const option = (name: string): SemanticNode => ({ id: `reports.${name}`, role: 'option', name, form: 'f', ...(v.reports?.includes(name) ? { state: { selected: true } } : {}) })
  return state([
    { id: 'first', role: 'textbox', name: 'First name', form: 'f', state: { required: true }, ...(v.first ? { value: v.first } : {}) },
    {
      id: 'email',
      role: 'textbox',
      name: 'Email',
      form: 'f',
      inputType: 'email',
      state: { required: true, ...(invalid ? { invalid: true } : {}) },
      ...(invalid ? { errorMessage: 'email.error' } : {}),
      ...(v.email ? { value: v.email } : {}),
    },
    ...(invalid ? [{ id: 'email.error', role: 'generic', text: 'Enter a valid email' }] : []),
    { id: 'access', role: 'radiogroup', name: 'Access', state: { required: true }, children: [radio('View reports'), radio('Edit reports')] },
    { id: 'reports', role: 'listbox', name: 'Shared reports', form: 'f', state: { multiselectable: true }, children: [option('Acquisition'), option('Audience')] },
    { id: 'digest', role: 'checkbox', name: 'Weekly digest', form: 'f', state: { checked: !!v.digest } },
    { id: 'start', role: 'textbox', name: 'Starts', form: 'f', inputType: 'date', ...(v.start ? { value: v.start } : {}) },
    { id: 'password', role: 'textbox', name: 'Password', form: 'f', inputType: 'password', ...(v.password ? { redacted: true } : {}) },
    { id: 'send', role: 'button', name: 'Send invite', form: 'f' },
  ])
}

describe('a form from the projection', () => {
  it('has one field per control, a radio group as one, in page order; buttons and secret fields are no fields', () => {
    const fields = formFields(invite({ first: 'Ana', access: 'View reports' }), 'f')
    expect(fields.map((f) => [f.key, f.label, f.kind, f.current])).toEqual([
      ['f1', 'First name', 'text', 'Ana'],
      ['f2', 'Email', 'text', undefined],
      ['f3', 'Access', 'radio', 'View reports'],
      ['f4', 'Shared reports', 'choices', undefined],
      ['f5', 'Weekly digest', 'toggle', false],
      ['f6', 'Starts', 'text', undefined],
    ])
    // a password is never the writer's to give: the user enters it
    expect(formFields(invite({ password: true }), 'f').map((f) => f.label)).not.toContain('Password')
  })

  it('tells the writer what each field takes and holds', () => {
    const fields = fieldsForWriter(formFields(invite({ password: true }, true), 'f'))
    expect(fields.find((f) => f.label === 'Email')).toEqual({ key: 'f2', label: 'Email', takes: 'text (email)', required: true, error: 'Enter a valid email' })
    expect(fields.find((f) => f.label === 'Starts')).toMatchObject({ takes: 'a date written YYYY-MM-DD' })
    expect(fields.find((f) => f.label === 'Access')).toMatchObject({ takes: 'one of its choices, exactly as written', choices: ['View reports', 'Edit reports'], required: true })
  })

  it("reads an invalid field's error from its description when its error message isn't a node of its own", () => {
    const form = state([
      { id: 'name', role: 'textbox', name: 'Name', form: 'f', description: 'Enter a name of at least 3 characters.', errorMessage: '#name-error', state: { invalid: true } },
      { id: 'city', role: 'textbox', name: 'City', form: 'f', description: 'Where you live' },
    ])
    const [name, city] = formFields(form, 'f')
    expect(name).toMatchObject({ error: 'Enter a name of at least 3 characters.', invalid: true })
    expect(name).not.toHaveProperty('description')
    // a valid field's description is only that
    expect(city).toMatchObject({ description: 'Where you live' })
    expect(city).not.toHaveProperty('error')
  })

  it("asks for every field's value or null, a choice among its own choices only", () => {
    const schema = fillSchema(formFields(invite(), 'f')) as { properties: Record<string, unknown>; required: string[]; additionalProperties: boolean }
    expect(schema.required).toEqual(['f1', 'f2', 'f3', 'f4', 'f5', 'f6'])
    expect(schema.additionalProperties).toBe(false)
    expect(schema.properties.f3).toEqual({ type: ['string', 'null'], enum: ['View reports', 'Edit reports', null] })
    expect(schema.properties.f4).toEqual({ type: ['array', 'null'], items: { type: 'string', enum: ['Acquisition', 'Audience'] } })
    expect(schema.properties.f5).toEqual({ type: ['boolean', 'null'] })
  })
})

describe('a fill', () => {
  it('sets each field in page order; null, or the value a field already holds, leaves it alone', () => {
    const fields = formFields(invite({ first: 'Ana' }), 'f')
    const { fills } = fillSteps(fields, { f1: 'Ana', f2: 'ana@x.test', f3: 'Edit reports', f4: ['Audience'], f5: true, f6: null })
    expect(fills.map((f) => f.step)).toEqual([
      undefined,
      { type: 'input', target: 'email', value: 'ana@x.test' },
      { type: 'click', target: 'access.Edit reports' },
      { type: 'select', target: 'reports', value: ['Audience'] },
      { type: 'toggle', target: 'digest', on: true },
    ])
    expect(fills.map((f) => f.said)).toEqual(['"Ana"', '"ana@x.test"', "'Edit reports'", "'Audience'", 'on'])
  })

  it("drops a choice the field doesn't offer, and says so", () => {
    const { fills, dropped } = fillSteps(formFields(invite(), 'f'), { f3: 'Owner', f1: 'Ana' })
    expect(fills.map((f) => f.field.label)).toEqual(['First name'])
    expect(dropped).toEqual(['Access'])
  })

  it('reads the form back: what it holds, what was left alone, required fields still empty, errors', () => {
    const fields = formFields(invite(), 'f')
    const { fills } = fillSteps(fields, { f1: 'Ana', f2: 'ana-at-x', f5: true })
    const after = invite({ first: 'Ana', email: 'ana-at-x', digest: true }, true)
    expect(fillReadback("form 'Invite contact'", fills, fields, after, 'f')).toBe(
      "filled form 'Invite contact': First name \"Ana\", Email \"ana-at-x\", Weekly digest on; " +
        'left alone: Shared reports, Starts; still empty, required: Access; ' +
        "now invalid: Email ('Enter a valid email')",
    )
  })

  it("says when a value didn't take", () => {
    const fields = formFields(invite(), 'f')
    const { fills } = fillSteps(fields, { f1: 'Ana', f2: 'ana@x.test', f3: 'View reports' })
    // the app trimmed the name and kept the email empty
    const after = invite({ first: 'An', access: 'View reports' })
    expect(fillReadback("form 'Invite contact'", fills, fields, after, 'f')).toContain('First name "Ana" (now "An"), Email "ana@x.test" (now empty)')
  })
})
