import { describe, expect, it } from 'vitest'
import type { SemanticNode, SemanticState } from '@agent-om/core'
import { NEXT_FILL, actionCandidates, answerCandidates, changeSummary, modelState, optionKeys, readCandidates, revealed, stepRequest, textCandidates } from './index'
import type { ChoiceQuestion } from './index'

// The package runs where its tests do: in Node, with no DOM. Importing it all
// here fails if any module reaches for the page at load time.

const state = (children: SemanticNode[]): SemanticState => ({
  revision: 1,
  timestamp: 0,
  context: { url: 'https://app.test/', path: '/', query: {}, title: 'Home' },
  root: { id: 'root', role: 'document', children },
})

describe('the agent package in Node', () => {
  const page = state([
    { id: 'nav', role: 'navigation', name: 'Primary', children: [{ id: 'nav.reports', role: 'link', name: 'Reports', href: '/reports' }] },
    { id: 'h', role: 'heading', name: 'Home', state: { level: 1 } },
    { id: 'search', role: 'searchbox', name: 'Search reports' },
  ])

  it('builds options and the model state from a snapshot', () => {
    const options = actionCandidates(page)
    expect(options.map((o) => o.description)).toEqual(["link 'Reports' → /reports", "type into searchbox 'Search reports'"])
    expect(modelState('show reports', page, [], { exclude: new Set() })).toMatchObject({ goal: 'show reports', path: '/', page: ["heading 'Home'"] })
  })

  it('keys an element the same way every time it is offered', () => {
    const keys = optionKeys()
    const [link] = actionCandidates(page)
    expect(keys.action(link)).toBe('a1')
    expect(keys.action(actionCandidates(page)[0])).toBe('a1')
  })

  it('offers runs of the goal\'s words as text', () => {
    expect(textCandidates('filter referrers by google')).toContain('google')
  })

  it("shows what a page says in prose (a node's loose text), and lets the answer point at it", () => {
    const campaign = state([
      { id: 'c', role: 'article', name: 'Spring Sale', text: 'Owner: Ana · Mar 1, 2026 – Mar 31, 2026', children: [{ id: 'h', role: 'heading', name: 'Spring Sale', state: { level: 1 } }] },
      // named content keeps its text for a read; a control's text is in its option
      { id: 'kpi', role: 'group', kind: 'metric', name: 'Spend', text: '$1,200' },
    ])
    expect(modelState('when did it run?', campaign, [], { exclude: new Set() }).page).toEqual([
      "article 'Spring Sale': Owner: Ana · Mar 1, 2026 – Mar 31, 2026",
      "heading 'Spring Sale'",
      "metric 'Spend'",
    ])
    expect(answerCandidates(campaign).map((a) => a.description)).toEqual(["article 'Spring Sale': Owner: Ana · Mar 1, 2026 – Mar 31, 2026", "metric 'Spend'"])
  })

  it('says a link within the page jumps to a section of it, not where it goes', () => {
    const doc = state([
      { id: 'h', role: 'heading', name: 'Set it up', state: { level: 2 } },
      { id: 'anchor', role: 'link', name: 'Link to “Set it up”', href: '#set-it-up' },
      { id: 'next', role: 'link', name: 'Consent mode', href: '/help/tracking/consent' },
    ])
    expect(actionCandidates(doc).map((o) => o.description)).toEqual([
      "link 'Link to “Set it up”' jumps to the section #set-it-up of this page",
      "link 'Consent mode' → /help/tracking/consent",
    ])
  })

  it("says what a toggle's description says, as for any other control", () => {
    const journey = state([
      { id: 'node', role: 'button', name: '/pricing', description: '5 visitors, 38% conversion.', state: { pressed: false } },
    ])
    expect(actionCandidates(journey).map((o) => o.description)).toEqual(["turn on button '/pricing' (off); '5 visitors, 38% conversion.'"])
  })

  it("says a toggle that's off is off (the outline shows only those that are on)", () => {
    const page = state([
      { id: 'require', role: 'switch', name: 'Require 2FA for all users', state: { checked: false } },
      { id: 'notify', role: 'checkbox', name: 'Email me', state: { checked: true } },
    ])
    expect(actionCandidates(page).map((o) => o.description)).toEqual([
      "turn on switch 'Require 2FA for all users' (off)",
      "turn off checkbox 'Email me'",
    ])
  })

  it('tells twins apart by the nearest container where they differ, not only the nearest one', () => {
    // a date range picker: two calendars, each showing October, each with its own 30 September
    const calendar = (group: string, id: string): SemanticNode => ({
      id: `${id}.group`,
      role: 'group',
      name: group,
      children: [{ id: `${id}.grid`, role: 'grid', name: 'October 2026', children: [{ id: `${id}.day`, role: 'button', name: 'September 30th' }] }],
    })
    const page = state([calendar('Start date', 'start'), calendar('End date', 'end')])
    expect(actionCandidates(page).map((o) => o.description)).toEqual([
      "button 'September 30th' in group 'Start date'",
      "button 'September 30th' in group 'End date'",
    ])
  })

  it("doesn't offer typing into a read-only field; the outline shows its value", () => {
    const page = state([
      { id: 'url', role: 'textbox', name: 'Tracking URL', value: 'https://t.app.test/p/abc', state: { readonly: true } },
      { id: 'name', role: 'textbox', name: 'Name', value: 'Newsletter opens' },
    ])
    expect(actionCandidates(page).map((o) => o.description)).toEqual(["type into textbox 'Name'"])
    expect(modelState('x', page, [], { exclude: new Set() }).page).toContain("textbox 'Tracking URL': 'https://t.app.test/p/abc'")
  })

  it('says when a table holds fewer rows than the page shows, and how many it holds', () => {
    // the projection keeps the first 50 rows of a 91-day table (totalRows counts them all)
    const days = (n: number) => Array.from({ length: n }, (_, i) => [`Day ${i + 1}`, '0'])
    const traffic = (rows: string[][], totalRows: number): SemanticNode => ({ id: 'traffic', role: 'table', name: 'Traffic over time', table: { columns: ['Date', 'Visitors'], rows, totalRows } })
    const cut = state([traffic(days(50), 91)])
    expect(readCandidates(cut, new Set(), new Set(), 1).map((o) => o.description)).toEqual(["read the first 50 of 91 rows of table 'Traffic over time'"])
    const lines = revealed(cut, new Set(['traffic']))[0].lines
    expect(lines).toHaveLength(51)
    expect(lines.at(-1)).toBe('(the other 41 rows of the 91 can\'t be read)')
    // a table held whole reads as before
    const whole = state([traffic(days(3), 3)])
    expect(readCandidates(whole, new Set(), new Set(), 1).map((o) => o.description)).toEqual(["read the rows of table 'Traffic over time' (3 on the page)"])
    expect(revealed(whole, new Set(['traffic']))[0].lines).toEqual(['Date: Day 1 · Visitors: 0', 'Date: Day 2 · Visitors: 0', 'Date: Day 3 · Visitors: 0'])
  })

  it('says a control that opens a dialog opens a dialog, not a list', () => {
    const page = state([
      { id: 'add', role: 'button', name: 'Add funnel', haspopup: 'dialog' },
      { id: 'more', role: 'button', name: 'Actions', haspopup: 'menu' },
      { id: 'pick', role: 'combobox', name: 'Currency', haspopup: 'listbox' },
    ])
    expect(actionCandidates(page).map((o) => o.description)).toEqual([
      "button 'Add funnel' opens a dialog",
      "button 'Actions' opens its menu",
      "combobox 'Currency' opens its list",
    ])
  })

  it('says a click changes nothing on the chosen radio and the open tab (the outline line reads like the option)', () => {
    const user = state([
      {
        id: 'tabs',
        role: 'tablist',
        name: 'User sections',
        children: [
          { id: 'tab.roles', role: 'tab', name: 'Role & teams', state: { selected: true } },
          { id: 'tab.perms', role: 'tab', name: 'Permissions' },
        ],
      },
      {
        id: 'role',
        role: 'radiogroup',
        name: 'Role',
        children: [
          { id: 'role.admin', role: 'radio', name: 'Admin', state: { checked: true } },
          { id: 'role.editor', role: 'radio', name: 'Editor', state: { checked: false } },
        ],
      },
    ])
    expect(actionCandidates(user).map((o) => o.description)).toEqual(["tab 'Role & teams' (selected)", "tab 'Permissions'", "Role: 'Admin' (chosen)", "Role: 'Editor'"])
    // the outline is as before
    expect(modelState('x', user, [], { exclude: new Set() }).page).toEqual(["tab 'Role & teams': selected", "Role: 'Admin'"])
  })
})

describe('filling a form in one step', () => {
  const field = (id: string, name: string, extra: Partial<SemanticNode> = {}): SemanticNode => ({ id, role: 'textbox', name, form: 'invite', ...extra })
  const invite = (fields: SemanticNode[], form: Partial<SemanticNode> = { name: 'Invite contact' }) =>
    state([{ id: 'invite', role: 'form', ...form, children: [...fields, { id: 'send', role: 'button', name: 'Send invite', form: 'invite' }] }])

  it('offers each form as one option, with its fields, only when there is a writer to give the values', () => {
    const page = invite([field('first', 'First name', { state: { required: true } }), field('email', 'Email', { inputType: 'email', state: { required: true } }), field('phone', 'Phone', { value: '+1 555' })])
    const fills = actionCandidates(page, new Set(), { fill: true }).filter((o) => o.step.type === 'fill')
    expect(fills.map((o) => o.description)).toEqual(["fill form 'Invite contact': First name, Email, Phone (2 required, empty)"])
    expect(optionKeys().action(fills[0])).toBe('f1')
    expect(actionCandidates(page).some((o) => o.step.type === 'fill')).toBe(false)
  })

  it('names a form without a name by its one button, else by its fields', () => {
    const fields = [field('a', 'Email'), field('b', 'Name')]
    const fill = (s: SemanticState) => actionCandidates(s, new Set(), { fill: true }).find((o) => o.step.type === 'fill')!.description
    expect(fill(invite(fields, {}))).toBe("fill the form with button 'Send invite': Email, Name")
    const noButton = state([{ id: 'invite', role: 'form', children: fields }])
    expect(fill(noButton)).toBe('fill the form with Email, Name')
  })

  it('fills a large form section by section, each part its own option', () => {
    const section = (id: string, name: string, n: number): SemanticNode => ({
      id,
      role: 'group',
      name,
      children: Array.from({ length: n }, (_, i) => field(`${id}.${i}`, `${name} ${i + 1}`)),
    })
    const big = state([{ id: 'invite', role: 'form', name: 'Settings', children: [section('a', 'Contact', 8), section('b', 'Shipping', 9), section('c', 'Billing', 25)] }])
    const fills = actionCandidates(big, new Set(), { fill: true }).filter((o) => o.step.type === 'fill')
    // Contact and Shipping fit in one part (17); Billing (25) is split in order
    expect(fills.map((o) => o.description.split(':')[0])).toEqual([
      "fill form 'Settings', sections 'Contact', 'Shipping'",
      "fill form 'Settings', section 'Billing'",
      "fill form 'Settings', section 'Billing'",
    ])
    expect(fills.map((o) => (o.step as { fill: { fields: unknown[] } }).fill.fields.length)).toEqual([17, 20, 5])
    const keys = optionKeys()
    expect(fills.map((o) => keys.action(o))).toEqual(['f1.1', 'f1.2', 'f1.3'])
  })
})

describe('the history after a popup closes', () => {
  const page = (children: SemanticNode[], modalId?: string): SemanticState => ({ ...state(children), context: { ...state([]).context, ...(modalId ? { modalId } : {}) } })
  const form: SemanticNode = { id: 'name', role: 'textbox', name: 'Key name', value: 'BI dashboard' }
  const dialog: SemanticNode = { id: 'confirm', role: 'dialog', name: "Confirm it's you", children: [{ id: 'ok', role: 'button', name: 'Confirm and create' }] }

  it('says what the page shows that the run has never seen (what the popup brought), not the whole page again', () => {
    // seen before the popup: the form; while it's open, only the popup is projected
    const seen = new Map([['name', form]])
    const before = page([dialog], 'confirm')
    const after = page([
      { ...form, value: undefined },
      { id: 'new-key', role: 'region', name: 'New key: BI dashboard' },
      { id: 'toast', role: 'status', text: 'Created the key BI dashboard.' },
    ])
    expect(changeSummary(before, after, seen)).toBe(
      "closed dialog 'Confirm it's you'; appeared: region 'New key: BI dashboard', status 'Created the key BI dashboard.'; textbox 'Key name' is now ''",
    )
    // nothing new: only the popup closing
    expect(changeSummary(before, page([form]), seen)).toBe("closed dialog 'Confirm it's you'")
  })

  it('names a message that appears or goes by what it says, popup or not', () => {
    const before = page([form])
    const alert: SemanticNode = { id: 'err', role: 'alert', text: 'Some fields need attention.' }
    expect(changeSummary(before, page([form, alert]))).toBe("appeared: alert 'Some fields need attention.'")
    expect(changeSummary(page([form, alert]), before)).toBe("went: alert 'Some fields need attention.'")
  })
})

describe('the next question, when a form can be filled at once', () => {
  it('asks to fill the form rather than field by field, only when a fill is offered', () => {
    const fields = state([{ id: 'f', role: 'form', name: 'Invite', children: [
      { id: 'a', role: 'textbox', name: 'First name', form: 'f' },
      { id: 'b', role: 'textbox', name: 'Email', form: 'f' },
    ] }])
    const instructions = (fill: boolean) => (stepRequest({}, actionCandidates(fields, new Set(), { fill }), [], optionKeys()).request.questions.next as ChoiceQuestion).instructions
    expect(instructions(true)).toContain(NEXT_FILL)
    expect(instructions(false)).not.toContain(NEXT_FILL)
  })
})

