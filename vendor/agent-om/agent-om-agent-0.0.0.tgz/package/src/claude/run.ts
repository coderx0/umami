import type { AgentEvent, AgentResult } from '../loop'
import { StepFailed, type AgentPage } from '../page'
import type { AskSecret } from '../secret'
import { claudeFirstMessage, claudeLoop, claudePrompt, type ClaudeLimits, type ClaudeRequest } from './loop'
import { Declined, ProjectionTools } from './tools'
import { projectionView } from './view'

// Claude on a page through the AgentPage interface, as a host runs it (the
// dashboard's Claude mode): the loop, the tools and the view the benchmarks
// run, put together. The host adds only what's its own: the user confirming
// a risky step (from the projection, never the model; declining ends the
// run), the user entering a secret field's secret (`askSecret`, which only the
// page gets; declining ends the run), the run's progress, its limits, and how
// the page is presented (AgentPage). It ends as our agent's runs do (AgentResult).

/** The benchmark's limits for its form tasks, the larger of its two. */
export const CLAUDE_LIMITS: ClaudeLimits = { actions: 30, modelCalls: 60 }

export type ClaudeRunOptions = {
  query: string
  apiKey: string
  page: AgentPage
  /** the host's own UI, never read or acted on */
  exclude: ReadonlySet<string>
  /** the app's sitemap as an outline (siteOutline), sent with the request */
  siteOutline?: string[]
  /** a risky target needs this to go ahead; declining ends the run */
  confirm: (prompt: string) => Promise<boolean>
  /** asks the user for a secret field's secret (fill_secret); declining ends the run. Without it, Claude has no fill_secret */
  askSecret?: AskSecret
  onEvent?: (e: AgentEvent) => void
  /** each request's outcome (time, retries, reply or error) */
  onRequest?: (request: ClaudeRequest) => void
  /** what was sent and received */
  log?: (type: string, data: Record<string, unknown>) => void
  limits?: ClaudeLimits
  signal?: AbortSignal
  /** answer requests without the API (tests) */
  fetch?: typeof fetch
}

/** A limit reached: ends the run. */
class Limit extends Error {}

export async function runClaude(o: ClaudeRunOptions): Promise<AgentResult> {
  const { page, signal } = o
  const limits = o.limits ?? CLAUDE_LIMITS
  let step = 0
  const onEvent = (e: AgentEvent) => {
    if (e.type === 'acting') step = e.step
    o.onEvent?.(e)
  }
  const hooks = projectionView({
    snapshot: () => page.observe(signal),
    now: () => page.snapshot(),
    async run(s) {
      try {
        await page.act(s, signal)
        return { ok: true }
      } catch (e) {
        if (e instanceof StepFailed) return { ok: false, reason: e.reason, message: e.message }
        throw e
      }
    },
    exclude: o.exclude,
    confirm: o.confirm,
    onEvent,
    ...(o.askSecret ? { askSecret: (field: string) => o.askSecret!(field, signal) } : {}),
  })
  const secrets = !!o.askSecret
  const tools = new ProjectionTools({ hooks, secrets })
  let actions = 0
  let calls = 0
  try {
    const end = await claudeLoop({
      apiKey: o.apiKey,
      system: claudePrompt(limits, { secrets }),
      tools: tools.tools,
      firstMessage: claudeFirstMessage(o.query, o.siteOutline),
      turn: tools.turn,
      // a view that was cleared can't be what the next one shows changes from
      cleared: () => tools.cleared(),
      signal,
      fetch: o.fetch,
      log: o.log,
      requesting: () => onEvent({ type: 'deciding', step: step + 1 }),
      measured: (r) => {
        calls++
        o.onRequest?.(r)
      },
      beforeTurn: (turn) => {
        actions += turn.filter(ProjectionTools.isAction).length
        if (actions > limits.actions) throw new Limit(`Stopped at the limit of ${limits.actions} actions without finishing.`)
      },
      afterTurn: () => {
        if (calls >= limits.modelCalls) throw new Limit(`Stopped at the limit of ${limits.modelCalls} model calls without finishing.`)
      },
    })
    if (end.signal === 'done') {
      // closing tags Claude sometimes leaves at the end of a parameter's text: the parameter's, and the call's after it
      const text = (end.answer ?? '').replace(/<\/answer>\s*(?:<\/invoke>\s*)?$/, '').trim()
      return text ? { status: 'done', message: 'Done.', text } : { status: 'done', message: 'Done.' }
    }
    if (end.signal === 'asked') return { status: 'blocked', message: end.detail || 'Claude needs something from you.' }
    if (end.signal === 'refused') return { status: 'failed', message: 'Claude declined the request.' }
    return { status: 'failed', message: 'Claude stopped without finishing.' }
  } catch (e) {
    if (e instanceof Declined) return { status: 'stopped', message: 'Cancelled.' }
    if (signal?.aborted) return { status: 'stopped', message: 'Stopped.' }
    return { status: 'failed', message: e instanceof Error ? e.message : String(e) }
  }
}
