import type { SemanticProjector, SemanticState } from '@agent-om/core'
import { ActionError, createActionExecutor, type ActionExecutor, type ActionExecutorOptions, type ActionStep } from '@agent-om/actions'
import { settled } from './settle'

// The page the agent works on, as an interface: it reads projection snapshots
// and runs executor steps, and never touches the DOM itself. In the page, it's
// the app's projector and our executor (projectorPage); from Node, a
// Playwright page with both injected into every document it loads, so the
// loop's state outlives a page load.

export type AgentPage = {
  /** a snapshot once the page has settled: no change for a moment, nothing loading or busy */
  observe(signal?: AbortSignal): Promise<SemanticState>
  /** a snapshot now, for checking a decision against the page just before acting on it */
  snapshot(): Promise<SemanticState>
  /** run one step; a step that can't be done throws StepFailed with the executor's reason */
  act(step: ActionStep, signal?: AbortSignal): Promise<void>
  /** bring a node into view (pointing at the answer); not finding it isn't a failure */
  scroll(nodeId: string): Promise<void>
}

/** A step the page couldn't do: `reason` is the executor's (`covered`, `no-option`, `aborted`…). */
export class StepFailed extends Error {
  readonly reason: string
  constructor(reason: string, message = reason) {
    super(message)
    this.name = 'StepFailed'
    this.reason = reason
  }
}

/** The page the app's own projector and executor show and act on (the agent running in the page). */
export function projectorPage(projector: SemanticProjector, executor: ActionExecutor): AgentPage {
  return {
    observe: (signal) => settled(projector, { signal }),
    snapshot: async () => projector.snapshot(),
    async act(step, signal) {
      try {
        await executor.run([step], { signal })
      } catch (e) {
        if (e instanceof ActionError) throw new StepFailed(e.reason, e.message)
        throw e
      }
    },
    async scroll(nodeId) {
      await executor.scroll(nodeId).catch(() => {})
    },
  }
}

/**
 * How a run looks to someone watching, set by the host: the target outlined
 * before each action (ms; 0: none) and a pause after each step (ms; 0: none).
 * They change only timing and visuals, never what the agent sees or decides;
 * none is what the benchmarks run.
 */
export type Presentation = { highlight?: number; pause?: number }

/** The page the app's own projector and executor show and act on, presented as the host chose (`projectorPage` with a presentation). */
export function presentedPage(
  projector: SemanticProjector,
  resolveTarget: NonNullable<ActionExecutorOptions['resolveTarget']>,
  { highlight = 0, pause = 0 }: Presentation = {},
): AgentPage {
  const page = projectorPage(projector, createActionExecutor({ resolveTarget, highlight }))
  if (!pause) return page
  return {
    ...page,
    async act(step, signal) {
      await page.act(step, signal)
      await new Promise<void>((resolve) => {
        const timer = setTimeout(done, pause)
        function done() {
          signal?.removeEventListener('abort', done)
          clearTimeout(timer)
          resolve()
        }
        signal?.addEventListener('abort', done, { once: true })
      })
    },
  }
}
