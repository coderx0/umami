import type { SemanticNode, SemanticState } from '@agent-om/core'
import type { ActionStep } from '@agent-om/actions'
import { indexNodes, nameOf, valueOf, type Located } from './describe'
import { isSecretField } from './secret'

// Filling a whole form in one step. The agent builds the form's fields from
// the projection (any form that follows the guidelines; nothing is written per
// form), the writer gives every field its value in one call (writer.ts), and
// the loop types them in page order, then reads the form back (loop.ts).
//
// A form's fields are the projected controls whose `form` is the form: the
// browser's own form ownership (inside the <form>, or linked with form=).
// Without a <form> there's no fill: the projection doesn't guess which fields
// belong together, so each stays a step of its own. Custom widgets whose
// choices only appear when opened (custom drop-downs, date pickers) aren't
// fields here either; they stay click steps. Nor are secret fields (a
// password): the writer never writes a secret, the user enters it (secret.ts).

/** Fields one fill covers at most; a larger form is filled section by section. */
export const FILL_CHUNK = 20

export type FormFieldKind = 'text' | 'number' | 'choice' | 'choices' | 'toggle' | 'radio'

export type FormField = {
  /** the writer's key for it: f1, f2… in page order */
  key: string
  /** the node acted on; for a radio group, the group (its radios in `radios`) */
  nodeId: string
  label: string
  kind: FormFieldKind
  required?: true
  /** its current value: text, the chosen item(s) or radio, on/off */
  current?: string | string[] | boolean
  /** what a choice, a multi-select or a radio group offers */
  choices?: string[]
  /** a radio group's radios */
  radios?: { name: string; nodeId: string }[]
  description?: string
  /** the page marks it invalid */
  invalid?: true
  /** its error message, while it's invalid */
  error?: string
  /** a native input's type when it sets the value's shape (date, email, number…) */
  inputType?: string
  /** the named section (group or fieldset) it sits in, for splitting a large form */
  section?: { id: string; name: string }
}

/** One fill option: a form, or one chunk of a large one. */
export type FormFill = {
  formId: string
  /** 1-based, and how many there are (1 of 1 for a form filled at once) */
  chunk: number
  chunks: number
  /** the chunk's sections, named, in page order (empty when the form isn't split) */
  sections: string[]
  fields: FormField[]
}

const TEXT_ROLES = new Set(['textbox', 'searchbox'])
const TOGGLE_ROLES = new Set(['checkbox', 'switch'])
const SECTION_ROLES = new Set(['group', 'region'])

/** Every fillable field of the form `formId`, in page order (keys f1, f2…). */
export function formFields(state: SemanticState, formId: string, exclude: ReadonlySet<string> = new Set()): FormField[] {
  const index = indexNodes(state.root)
  const out: FormField[] = []
  const groups = new Map<string, FormField>()
  for (const loc of index.values()) {
    const { node, parents } = loc
    if (node.form !== formId || node.state?.disabled || node.state?.readonly) continue
    if (exclude.has(node.id) || parents.some((p) => exclude.has(p.id))) continue
    if (node.role === 'radio') {
      // a radio group is one field: the radios sharing a parent
      const group = parents.at(-1)
      if (!group || !node.name) continue
      let field = groups.get(group.id)
      if (!field) {
        field = { key: '', nodeId: group.id, label: group.name ?? 'options', kind: 'radio', choices: [], radios: [], ...common(group, parents.slice(0, -1), index) }
        groups.set(group.id, field)
        out.push(field)
      }
      field.choices!.push(node.name)
      field.radios!.push({ name: node.name, nodeId: node.id })
      if (node.state?.checked === true) field.current = node.name
      if (node.state?.required) field.required = true
      continue
    }
    const field = fieldOf(loc, index)
    if (field) out.push(field)
  }
  return out.map((f, i) => ({ ...f, key: `f${i + 1}` }))
}

function fieldOf({ node, parents }: Located, index: ReadonlyMap<string, Located>): FormField | undefined {
  const base = { key: '', nodeId: node.id, label: node.name ?? nameOf(node), ...common(node, parents, index) }
  const value = valueOf(node)
  if (TEXT_ROLES.has(node.role) || node.role === 'spinbutton') {
    if (isSecretField(node)) return undefined
    return {
      ...base,
      kind: node.role === 'spinbutton' ? 'number' : 'text',
      ...(value ? { current: value } : {}),
      ...(node.inputType ? { inputType: node.inputType } : {}),
    }
  }
  if (node.items && node.role === 'combobox') {
    // a native drop-down <select>: its choices are its items
    return { ...base, kind: 'choice', choices: node.items, ...(value ? { current: value } : {}) }
  }
  if (node.role === 'listbox' && node.children?.length) {
    // a native list <select> (a multi-select among them): its choices are its options
    const options = node.children.filter((c) => c.role === 'option' && c.name && !c.state?.disabled)
    if (!options.length) return undefined
    const choices = options.map((o) => o.name!)
    const chosen = options.filter((o) => o.state?.selected).map((o) => o.name!)
    if (node.state?.multiselectable) return { ...base, kind: 'choices', choices, ...(chosen.length ? { current: chosen } : {}) }
    return { ...base, kind: 'choice', choices, ...(chosen.length ? { current: chosen[0] } : {}) }
  }
  if (TOGGLE_ROLES.has(node.role)) return { ...base, kind: 'toggle', current: node.state?.checked === true }
  return undefined
}

/**
 * What every kind of field says: required, its description, its error, its
 * section. An invalid field's error is its error message's text (aria-errormessage);
 * when that isn't a node of its own, its description (aria-describedby), which
 * is the other way guidelines 1.8 ties an error to its field.
 */
function common(node: SemanticNode, parents: SemanticNode[], index: ReadonlyMap<string, Located>) {
  const invalid = !!node.state?.invalid
  const linked = invalid && node.errorMessage ? errorText(index.get(node.errorMessage)?.node) : undefined
  const error = linked ?? (invalid ? node.description : undefined)
  const description = error === node.description ? undefined : node.description
  const section = [...parents].reverse().find((p) => SECTION_ROLES.has(p.role) && p.name)
  return {
    ...(node.state?.required ? { required: true as const } : {}),
    ...(invalid ? { invalid: true as const } : {}),
    ...(description ? { description } : {}),
    ...(error ? { error } : {}),
    ...(section ? { section: { id: section.id, name: section.name! } } : {}),
  }
}

const errorText = (node?: SemanticNode) => node?.text ?? node?.name

/**
 * The form's fields as fill options: all at once up to FILL_CHUNK fields;
 * beyond that, in chunks by section in page order, each chunk up to
 * FILL_CHUNK fields (a section larger than that is split in order).
 */
export function formFills(state: SemanticState, formId: string, exclude?: ReadonlySet<string>): FormFill[] {
  const fields = formFields(state, formId, exclude)
  if (fields.length <= FILL_CHUNK) return fields.length ? [{ formId, chunk: 1, chunks: 1, sections: [], fields }] : []
  // runs of fields in the same section, in page order
  const runs: FormField[][] = []
  for (const f of fields) {
    const last = runs.at(-1)
    if (last && last[0].section?.id === f.section?.id) last.push(f)
    else runs.push([f])
  }
  const chunks: FormField[][] = []
  for (const run of runs) {
    for (let i = 0; i < run.length; i += FILL_CHUNK) {
      const part = run.slice(i, i + FILL_CHUNK)
      const last = chunks.at(-1)
      if (last && i === 0 && last.length + part.length <= FILL_CHUNK) last.push(...part)
      else chunks.push(part)
    }
  }
  return chunks.map((chunk, i) => ({
    formId,
    chunk: i + 1,
    chunks: chunks.length,
    sections: [...new Set(chunk.flatMap((f) => (f.section ? [f.section.name] : [])))],
    fields: chunk,
  }))
}

/**
 * The form, as an option names it: its accessible name ("form 'Invite
 * contact'"); without one, its button when it has just one ("the form with
 * button 'Send invite'": the button belongs to the form, by the browser's
 * form ownership); without either, its fields only ("the form with Email,
 * Password").
 */
export function formName(state: SemanticState, formId: string, fields: FormField[]): { name: string; byFields: boolean } {
  const index = indexNodes(state.root)
  const form = index.get(formId)?.node
  if (form?.name) return { name: nameOf(form), byFields: false }
  const buttons = [...index.values()].filter(({ node }) => node.form === formId && node.role === 'button' && node.name)
  if (buttons.length === 1) return { name: `the form with button '${buttons[0].node.name}'`, byFields: false }
  return { name: `the form with ${fields.map((f) => f.label).join(', ')}`, byFields: true }
}

/**
 * A fill option's description, after "fill <form's name>": the part of a
 * large form, its fields (unless the name lists them), the required ones still
 * empty: ": Email, First name, … (2 required, empty)".
 */
export function fillRest(fill: FormFill, byFields: boolean): string {
  const part =
    fill.chunks === 1 ? '' : fill.sections.length ? `, ${fill.sections.length > 1 ? 'sections' : 'section'} ${fill.sections.map((s) => `'${s}'`).join(', ')}` : `, part ${fill.chunk} of ${fill.chunks}`
  const empty = fill.fields.filter((f) => f.required && isEmpty(f)).length
  const fields = byFields && fill.chunks === 1 ? '' : `: ${fill.fields.map((f) => f.label).join(', ')}`
  return `${part}${fields}${empty ? ` (${empty} required, empty)` : ''}`
}

const isEmpty = (f: FormField) => f.current === undefined || f.current === '' || (Array.isArray(f.current) && !f.current.length)

/** A field's value as the writer gives it: text, a number, a choice, choices, on/off, or null to leave it alone. */
export type FieldValue = string | number | boolean | string[] | null

/** The fields as the writer sees them: what each takes, and what it holds now. */
export function fieldsForWriter(fields: FormField[]) {
  return fields.map((f) => ({
    key: f.key,
    label: f.label,
    takes: takes(f),
    ...(f.required ? { required: true } : {}),
    ...(f.current !== undefined && f.current !== '' ? { current: f.current } : {}),
    ...(f.choices ? { choices: f.choices } : {}),
    ...(f.description ? { description: f.description } : {}),
    ...(f.error ? { error: f.error } : {}),
    ...(f.section ? { section: f.section.name } : {}),
  }))
}

const FORMATS: Record<string, string> = { date: 'YYYY-MM-DD', time: 'HH:MM', 'datetime-local': 'YYYY-MM-DDTHH:MM', month: 'YYYY-MM', week: 'YYYY-Www' }

function takes(f: FormField) {
  if (f.kind === 'toggle') return 'on (true) or off (false)'
  if (f.kind === 'number') return 'a number'
  if (f.kind === 'choice' || f.kind === 'radio') return 'one of its choices, exactly as written'
  if (f.kind === 'choices') return 'a list of its choices, exactly as written'
  const format = f.inputType && FORMATS[f.inputType]
  return format ? `a ${f.inputType} written ${format}` : f.inputType ? `text (${f.inputType})` : 'text'
}

/** The JSON Schema of the writer's reply: every field's key, its value or null. */
export function fillSchema(fields: FormField[]): Record<string, unknown> {
  const properties = Object.fromEntries(
    fields.map((f) => {
      if (f.kind === 'toggle') return [f.key, { type: ['boolean', 'null'] }]
      if (f.kind === 'number') return [f.key, { type: ['number', 'null'] }]
      if (f.kind === 'choices') return [f.key, { type: ['array', 'null'], items: { type: 'string', enum: f.choices } }]
      if (f.kind === 'choice' || f.kind === 'radio') return [f.key, { type: ['string', 'null'], enum: [...f.choices!, null] }]
      return [f.key, { type: ['string', 'null'] }]
    }),
  )
  return { type: 'object', properties, required: fields.map((f) => f.key), additionalProperties: false }
}

/** One field's part of a fill: the step that sets it (none when it already holds the value), and the value as said in the history. */
export type FieldFill = { field: FormField; step?: ActionStep; said: string }

/**
 * The steps that set the fields to the writer's values, in page order: null
 * leaves a field alone, and so does the value it already holds. A value a field
 * can't take (a choice it doesn't offer) is dropped, said so.
 */
export function fillSteps(fields: FormField[], values: Record<string, FieldValue | undefined>): { fills: FieldFill[]; dropped: string[] } {
  const fills: FieldFill[] = []
  const dropped: string[] = []
  for (const f of fields) {
    const v = values[f.key]
    if (v === null || v === undefined) continue
    const said = Array.isArray(v) ? v.map((x) => `'${x}'`).join(', ') : typeof v === 'boolean' ? (v ? 'on' : 'off') : f.kind === 'text' || f.kind === 'number' ? `"${v}"` : `'${v}'`
    const step = stepFor(f, v)
    if (step === false) dropped.push(f.label)
    else fills.push({ field: f, ...(step ? { step } : {}), said })
  }
  return { fills, dropped }
}

/** The step for one value; undefined when the field already holds it, false when it can't take it. */
function stepFor(f: FormField, v: Exclude<FieldValue, null>): ActionStep | undefined | false {
  switch (f.kind) {
    case 'text':
    case 'number': {
      const text = String(v)
      return f.current === text ? undefined : { type: 'input', target: f.nodeId, value: text }
    }
    case 'choice':
      if (typeof v !== 'string' || !f.choices!.includes(v)) return false
      return f.current === v ? undefined : { type: 'select', target: f.nodeId, value: v }
    case 'choices': {
      const wanted = Array.isArray(v) ? v : [String(v)]
      if (!wanted.every((w) => f.choices!.includes(w))) return false
      const now = Array.isArray(f.current) ? f.current : []
      return now.length === wanted.length && wanted.every((w) => now.includes(w)) ? undefined : { type: 'select', target: f.nodeId, value: wanted }
    }
    case 'toggle':
      if (typeof v !== 'boolean') return false
      return f.current === v ? undefined : { type: 'toggle', target: f.nodeId, on: v }
    case 'radio': {
      const radio = f.radios!.find((r) => r.name === v)
      if (!radio) return false
      return f.current === v ? undefined : { type: 'click', target: radio.nodeId }
    }
  }
}

/**
 * The form after a fill, for the history: what each field holds now, which
 * were left alone, which required ones are still empty, and which are now
 * invalid, with their error.
 */
export function fillReadback(name: string, filled: FieldFill[], fields: FormField[], after: SemanticState, formId: string): string {
  const now = new Map(formFields(after, formId).map((f) => [f.nodeId, f]))
  const touched = new Set(filled.map((f) => f.field.nodeId))
  const parts: string[] = []
  const set = filled.map(({ field, said }) => {
    const n = now.get(field.nodeId)
    // what didn't take: the field holds something other than what was set
    const took = !n || said === saidOf(n)
    return `${field.label} ${said}${took ? '' : ` (now ${n.current === undefined || n.current === '' ? 'empty' : saidOf(n)})`}`
  })
  parts.push(`filled ${name}: ${set.join(', ') || 'nothing'}`)
  const alone = fields.filter((f) => !touched.has(f.nodeId) && !(f.required && isEmpty(now.get(f.nodeId) ?? f)))
  if (alone.length) parts.push(`left alone: ${alone.map((f) => f.label).join(', ')}`)
  const empty = fields.filter((f) => f.required && isEmpty(now.get(f.nodeId) ?? f))
  if (empty.length) parts.push(`still empty, required: ${empty.map((f) => f.label).join(', ')}`)
  const invalid = fields.map((f) => now.get(f.nodeId)).filter((f): f is FormField => !!f?.invalid)
  if (invalid.length) parts.push(`now invalid: ${invalid.map((f) => (f.error ? `${f.label} ('${f.error}')` : f.label)).join(', ')}`)
  return parts.join('; ')
}

function saidOf(f: FormField) {
  const v = f.current
  if (v === undefined) return ''
  if (Array.isArray(v)) return v.map((x) => `'${x}'`).join(', ')
  if (typeof v === 'boolean') return v ? 'on' : 'off'
  return f.kind === 'text' || f.kind === 'number' ? `"${v}"` : `'${v}'`
}
