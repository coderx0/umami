# @agent-om/react

React adapter for [`@agent-om/core`](https://www.npmjs.com/package/@agent-om/core),
the Agent Object Model: a live, compact tree of what a web page offers, built
from its semantic HTML and ARIA, for AI agents and automated tests.

> **Status:** 0.x. The API can still change.

```sh
npm install @agent-om/core @agent-om/react
```

React (18 or later) and `@agent-om/core` are peer dependencies, so an app holds
one copy of the projection and one metadata registry.

## Use

`useSemantic(id, meta)` gives an element a stable id and metadata. Spread the
props it returns on the element that represents the thing:

```tsx
import { useSemantic } from '@agent-om/react'

function VisitorsCard({ visitors }: { visitors: number }) {
  const semantic = useSemantic('kpi.visitors', {
    kind: 'metric',
    value: visitors,                          // the raw number behind "112.9k"
    data: { label: 'Unique visitors' },       // structured data, which attributes can't carry
  })
  return <section {...semantic} aria-label="Unique visitors">…</section>
}
```

The metadata is registered while the component is mounted and re-registered
only when it changes. It takes the same fields as the `data-agentom-*`
attributes (`kind`, `description`, `value`, `action`, `purpose`, `risk`,
`confirmation`, `requires`) plus `data`, and wins over them.

The projector itself comes from core:

```ts
import { createSemanticProjector } from '@agent-om/core'

const projector = createSemanticProjector()
projector.snapshot()
```

## Documentation

- [How it works](https://github.com/TheAsyncLooop/agent-om/blob/master/docs/semantic-projection.md)
- [Authoring guidelines](https://github.com/TheAsyncLooop/agent-om/blob/master/docs/guidelines.md)
- [The repository](https://github.com/TheAsyncLooop/agent-om)

## License

[Apache-2.0](https://github.com/TheAsyncLooop/agent-om/blob/master/LICENSE). Copyright 2026 Sumeet Debnath and Prathmesh Vhatkar.
