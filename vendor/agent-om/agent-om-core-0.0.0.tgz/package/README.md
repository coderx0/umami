# @agent-om/core

The Agent Object Model: a live, compact tree of what a web page offers (its
controls, content, state and context), built from the page's own semantic
HTML and ARIA plus a few `data-agentom-*` attributes. AI agents and automated
tests read it instead of screenshots or the raw DOM, and act on its entries by
stable ids.

> **Status:** 0.x. The API and the shape of the projection can still change.

```sh
npm install @agent-om/core
```

Plain DOM and TypeScript: any framework or none. Its one dependency is
`dom-accessibility-api`. For React, add
[`@agent-om/react`](https://www.npmjs.com/package/@agent-om/react).

## What it looks like

This markup:

```html
<main>
  <h1>Billing</h1>
  <div class="card"><div class="row">
    <label for="plan">Plan</label>
    <select id="plan"><option>Free</option><option selected>Pro</option></select>
  </div></div>
  <label>Password <input type="password" autocomplete="current-password"></label>
  <button>Save changes</button>
  <button data-agentom-id="subscription.cancel" data-agentom-risk="destructive"
          data-agentom-confirmation="required">Cancel subscription</button>
</main>
```

with the password field filled in, projects to:

```json
{
  "id": "main",
  "role": "main",
  "children": [
    { "id": "heading:billing", "role": "heading", "name": "Billing", "state": { "level": 1 } },
    { "id": "combobox:plan", "role": "combobox", "name": "Plan", "value": "Pro", "domId": "plan", "items": ["Free", "Pro"] },
    { "id": "textbox:password", "role": "textbox", "name": "Password", "redacted": true, "inputType": "password" },
    { "id": "button:save-changes", "role": "button", "name": "Save changes" },
    { "id": "subscription.cancel", "role": "button", "name": "Cancel subscription", "risk": "destructive", "confirmationRequired": true }
  ]
}
```

The layout `div`s vanished, the label became the select's name and the
selected option its value. The password field says it is filled in without
its value: secrets never leave the page. The cancel button carries its own id,
its risk and the need to confirm it, none of which HTML can say.

## Use

```ts
import { createSemanticProjector, actionableNodes } from '@agent-om/core'

const projector = createSemanticProjector({
  context: () => ({ screen: 'billing' }), // what only the app knows
})

const state = projector.snapshot()   // { revision, timestamp, context, root }
actionableNodes(state)               // what can be acted on now, in page order

projector.subscribe((state, patch) => {
  // after every change: patch.added, patch.removed, patch.changed (node ids)
})

const button = projector.resolve('subscription.cancel')   // the element behind an id
if (button instanceof HTMLElement) button.click()
projector.stop()
```

The projector watches the page and keeps the tree current, re-projecting only
what changed. Options include `root` (default `document.body`), `context`,
`location` (for routers that aren't the address bar) and `onWarning` (invalid
metadata, reported once).

## Metadata

Where HTML and ARIA can't say something, an attribute can:

| Attribute | Says |
|---|---|
| `data-agentom-id` | a stable id; ids of unannotated nodes inside are scoped under it |
| `data-agentom-kind` | a category: `metric`, `filter`, `section`… |
| `data-agentom-desc` | a description (overrides ARIA's) |
| `data-agentom-value` | a raw value behind formatted text (`112937` for "112.9k") |
| `data-agentom-action`, `data-agentom-purpose` | what activating it does, and the goal it serves |
| `data-agentom-risk` | `sensitive` or `destructive` |
| `data-agentom-confirmation` | `required`: confirm before acting |
| `data-agentom-requires` | ids that must be done first |
| `data-agentom-ignore` | leave this subtree out |
| `data-agentom-redact` | never project this field's value |

Metadata is read only on an element that has a `data-agentom-id` (except
`ignore` and `redact`). From code, `registerMeta(id, meta)` sets the same
fields, including structured `data`; it wins over the attributes.

## The semantic sitemap

`@agent-om/core/sitemap` is the format for an app's pages as a tree of path
templates, published at `/semantic-sitemap.json`. It has no DOM, so build
plugins and bots use it too:

```ts
import { validateSitemap, locate } from '@agent-om/core/sitemap'

validateSitemap(map)                                  // [] when the map follows the rules
locate(map, '/campaigns/42', { tab: 'ad-groups' })    // the template, its trail, params and view
```

## Documentation

- [How it works](https://github.com/TheAsyncLooop/agent-om/blob/master/docs/semantic-projection.md):
  the projection, every node field, live updates, the decision log
- [Authoring guidelines](https://github.com/TheAsyncLooop/agent-om/blob/master/docs/guidelines.md):
  how to build pages that project well (the same fixes help accessibility)
- [The semantic sitemap](https://github.com/TheAsyncLooop/agent-om/blob/master/docs/sitemap.md)
- [The repository](https://github.com/TheAsyncLooop/agent-om): the demo app,
  an agent built on the projection, and benchmark results

## License

[Apache-2.0](https://github.com/TheAsyncLooop/agent-om/blob/master/LICENSE). Copyright 2026 Sumeet Debnath and Prathmesh Vhatkar.
